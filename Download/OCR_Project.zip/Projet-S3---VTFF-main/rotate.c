#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
    if (argc != 3) 
    {
        return EXIT_FAILURE;
    }

    const char *image_path = argv[1];
    long angle = strtoul(argv[2], NULL, 10);


    if (SDL_Init(SDL_INIT_VIDEO) != 0) 
    {
        SDL_Log("Pb SDL: %s", SDL_GetError());
        return 1;
    }

    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) 
    {
        SDL_Log("Pb SDL_image: %s", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Surface *image_surface = IMG_Load(image_path);
    if (!image_surface) 
    {
        SDL_Log("Pb img %s: %s. .PNG ONLY !", image_path, IMG_GetError());
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // Création d'une fenêtre et d'un rendu (non affichée) !!
    SDL_Window *window = SDL_CreateWindow("Yanis x Vanatathan : A sauced relationship", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, image_surface->w, image_surface->h, SDL_WINDOW_HIDDEN);
    if (!window) 
    {
        SDL_Log("gen fenetre: %s", SDL_GetError());
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if (!renderer) 
    {
        SDL_Log("rendu be ded: %s", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // Création d'une texture à partir de l'image
    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, image_surface);
    if (!texture) 
    {
        SDL_Log("rm -rf texture: %s", SDL_GetError());
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // Calcul des dimensions de la nouvelle image après rotation
    int w = image_surface->w;
    int h = image_surface->h;
    double rad_angle = angle * (M_PI / 180.0);

    int new_w = (int)(fabs(w * cos(rad_angle)) + fabs(h * sin(rad_angle)));
    int new_h = (int)(fabs(w * sin(rad_angle)) + fabs(h * cos(rad_angle)));

    // Création d'une texture cible pour le rendu
    SDL_Texture *target_texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, new_w, new_h);
    if (!target_texture) 
    {
        SDL_Log("pb texture changed: %s", SDL_GetError());
        SDL_DestroyTexture(texture);
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // Définition de la texture cible pour le rendu
    if (SDL_SetRenderTarget(renderer, target_texture) != 0) 
    {
        SDL_Log("%s", SDL_GetError());
    }

    // Effacement du rendu avec transparence
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_RenderClear(renderer);

    //rotation
    SDL_Point center = { w / 2, h / 2 };
    SDL_Rect dest_rect = { (new_w - w) / 2, (new_h - h) / 2, w, h };

    if (SDL_RenderCopyEx(renderer, texture, NULL, &dest_rect, (double)angle, &center, SDL_FLIP_NONE) != 0) 
    {
        SDL_Log("Pb remplacement: %s", SDL_GetError());
    }

    // reset
    SDL_SetRenderTarget(renderer, NULL);

    // Création d'une surface pour enregistrer l'image pivotée
    SDL_Surface *rotated_surface = SDL_CreateRGBSurfaceWithFormat(0, new_w, new_h, 32, SDL_PIXELFORMAT_RGBA32);
    if (!rotated_surface) 
    {
        SDL_Log("Pb surface: %s", SDL_GetError());
        SDL_DestroyTexture(target_texture);
        SDL_DestroyTexture(texture);
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // Lecture des pixels de la texture cible dans la surface
    if (SDL_SetRenderTarget(renderer, target_texture) != 0) 
    {
        SDL_Log("Pb next target : %s", SDL_GetError());
    }
    if (SDL_RenderReadPixels(renderer, NULL, SDL_PIXELFORMAT_RGBA32, rotated_surface->pixels, rotated_surface->pitch) != 0) 
    {
        SDL_Log("pixels...: %s", SDL_GetError());
        SDL_FreeSurface(rotated_surface);
        SDL_DestroyTexture(target_texture);
        SDL_DestroyTexture(texture);
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    if (IMG_SavePNG(rotated_surface, image_path) != 0) 
    {
        SDL_Log("READ ONLY ?! : %s", IMG_GetError());
    } else 
    {
        SDL_Log("check %s", image_path);
    }

    // quit
    SDL_FreeSurface(rotated_surface);
    SDL_DestroyTexture(target_texture);
    SDL_DestroyTexture(texture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_FreeSurface(image_surface);
    IMG_Quit();
    SDL_Quit();

    return 0;
}
