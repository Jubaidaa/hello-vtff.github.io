#include <stdlib.h>
#include <stdio.h>
#include <math.h>

double sigmoid(double x) {
        if (x > 20) return 1.0;
        if (x < -20) return 0.0;
        double z = exp(-x);
        return 1.0 / (1.0 + z);
}

double dSigmoid(double x) {
        return x * (1.0 - x);
}

double init_weights() {
        double placeholder = ((double)rand()) / ((double)RAND_MAX);
        return placeholder;
}

void shuffle(int *array, size_t n) {
        if (n > 1) {
                size_t i;
                for (i = 0; i < n - 1; i++) {
                        size_t j = i + rand() / (RAND_MAX / (n - i) + 1);
                        int t = array[j];
                        array[j] = array[i];
                        array[i] = t;
                }
        }
}

#define NUM_INPUTS 2
#define NUM_HIDDEN 2
#define NUM_OUTPUTS 1
#define NUM_TRAINING_SETS 4

int main() {
        // Learning rate
        const double lr = 0.1f;

        double hiddenLayer[NUM_HIDDEN];
        double outputLayer[NUM_OUTPUTS];
        double hiddenLayerBias[NUM_HIDDEN];
        double outputLayerBias[NUM_OUTPUTS];
        double hiddenWeights[NUM_INPUTS][NUM_HIDDEN];
        double outputWeights[NUM_HIDDEN][NUM_OUTPUTS];

        double trainingInputs[NUM_TRAINING_SETS][NUM_INPUTS] = {
                {0.0f, 0.0f},
                {1.0f, 0.0f},
                {0.0f, 1.0f},
                {1.0f, 1.0f}
        };

        double trainingOutputs[NUM_TRAINING_SETS][NUM_OUTPUTS] = {
                {1.0f},
                {0.0f},
                {0.0f},
                {1.0f}
        };

        // Initialize weights
        for (int i = 0; i < NUM_INPUTS; i++) {
                for (int j = 0; j < NUM_HIDDEN; j++) {
                        hiddenWeights[i][j] = init_weights();
                }
        }

        for (int i = 0; i < NUM_HIDDEN; i++) {
                for (int j = 0; j < NUM_OUTPUTS; j++) {
                        outputWeights[i][j] = init_weights();
                }
        }

        for (int i = 0; i < NUM_OUTPUTS; i++) {
                outputLayerBias[i] = init_weights();
        }

        for (int i = 0; i < NUM_HIDDEN; i++) {
                hiddenLayerBias[i] = init_weights();
        }

        int trainingSetOrder[] = {0, 1, 2, 3};
        int numEpochs = 50000;
        // Training loop
        for (int epoch = 0; epoch < numEpochs; epoch++) {
                shuffle(trainingSetOrder, NUM_TRAINING_SETS);
                for (int x = 0; x < NUM_TRAINING_SETS; x++) {
                        int i = trainingSetOrder[x];

                        // Forward pass
                        for (int j = 0; j < NUM_HIDDEN; j++) {
                                double activation = hiddenLayerBias[j];
                                for (int k = 0; k < NUM_INPUTS; k++) {
                                        activation += trainingInputs[i][k] * hiddenWeights[k][j];
                                }
                                hiddenLayer[j] = sigmoid(activation);
                        }

                        // Compute output layer activation
                        for (int j = 0; j < NUM_OUTPUTS; j++) {
                                double activation = outputLayerBias[j];
                                for (int k = 0; k < NUM_HIDDEN; k++) {
                                        activation += hiddenLayer[k] * outputWeights[k][j];
                                }
                                outputLayer[j] = sigmoid(activation);
                        }

                        printf("Entrée: %g %g \033[0;32mSortie: %g\033[0m \033[0;34mSortie attendue: %g\033[0m\n",
                                        trainingInputs[i][0], trainingInputs[i][1], outputLayer[0], trainingOutputs[i][0]);

                        // Backpropagation
                        double deltaOutput[NUM_OUTPUTS];
                        for (int j = 0; j < NUM_OUTPUTS; j++) {
                                double error = (trainingOutputs[i][j] - outputLayer[j]);
                                deltaOutput[j] = error * dSigmoid(outputLayer[j]);
                        }

                        double deltaHidden[NUM_HIDDEN];
                        for (int j = 0; j < NUM_HIDDEN; j++) {
                                double error = 0.0f;
                                for (int k = 0; k < NUM_OUTPUTS; k++) {
                                        error += deltaOutput[k] * outputWeights[j][k];
                                }
                                deltaHidden[j] = error * dSigmoid(hiddenLayer[j]);
                        }

                        // Apply change in output weights
                        for (int j = 0; j < NUM_OUTPUTS; j++) {
                                outputLayerBias[j] += deltaOutput[j] * lr;
                                for (int k = 0; k < NUM_HIDDEN; k++) {
                                        outputWeights[k][j] += hiddenLayer[k] * deltaOutput[j] * lr;
                                }
                        }

                        for (int j = 0; j < NUM_HIDDEN; j++) {
                                hiddenLayerBias[j] += deltaHidden[j] * lr;
                                for (int k = 0; k < NUM_INPUTS; k++) {
                                        hiddenWeights[k][j] += trainingInputs[i][k] * deltaHidden[j] * lr;
                                }
                        }
                }
        }
// Print final weights after training
        printf("Poids finaux caches: \n");
        for (int j = 0; j < NUM_HIDDEN; j++) {
                for (int k = 0; k < NUM_INPUTS; k++) {
                        printf("%f ", hiddenWeights[k][j]);
                }
        }

        printf("\nBiais finaux caches: \n");
        for (int j = 0; j < NUM_HIDDEN; j++) {
                printf("%f ", hiddenLayerBias[j]);
        }

        printf("\nPoids finaux de sortie: \n");
        for (int j = 0; j < NUM_OUTPUTS; j++) {
                for (int k = 0; k < NUM_HIDDEN; k++) {
                        printf("%f ", outputWeights[k][j]);
                }
        }

        printf("\nBiais finaux de sortie: \n");
        for (int j = 0; j < NUM_OUTPUTS; j++) {
                printf("%f ", outputLayerBias[j]);
                printf("\n      ✅  Fini !  ✅\n");
        }

        return 0;
}

