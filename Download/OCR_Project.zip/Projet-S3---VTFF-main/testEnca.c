#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdlib.h>
#include <stdio.h>

#define LETTER_MIN_WIDTH 1
#define LETTER_MAX_WIDTH 50
#define MAX_VERTICAL_DISTANCE 20
#define WORD_SPACING 3
#define MAX_LETTER_SPACING 50

typedef struct {
    int x;
    int y;
} Point;

void draw_empty_rect(SDL_Surface* surface, SDL_Rect rect, Uint32 color) {
    Uint32* pixels = (Uint32*)surface->pixels;
    int width = surface->w;

    for (int x = rect.x; x < rect.x + rect.w; x++) {
        if (x >= 0 && x < width && rect.y >= 0 && rect.y < surface->h) {
            pixels[rect.y * width + x] = color;
        }
    }

    for (int x = rect.x; x < rect.x + rect.w; x++) {
        if (x >= 0 && x < width && (rect.y + rect.h - 1) >= 0 && (rect.y + rect.h - 1) < surface->h) {
            pixels[(rect.y + rect.h - 1) * width + x] = color;
        }
    }

    for (int y = rect.y; y < rect.y + rect.h; y++) {
        if (rect.x >= 0 && rect.x < width && y >= 0 && y < surface->h) {
            pixels[y * width + rect.x] = color;
        }
    }

    for (int y = rect.y; y < rect.y + rect.h; y++) {
        if ((rect.x + rect.w - 1) >= 0 && (rect.x + rect.w - 1) < width && y >= 0 && y < surface->h) {
            pixels[y * width + (rect.x + rect.w - 1)] = color;
        }
    }
}

int is_black_pixel(Uint32 pixel, SDL_PixelFormat* format) {
    Uint8 r, g, b;
    SDL_GetRGB(pixel, format, &r, &g, &b);
    return (r < 100 && g < 100 && b < 100);
}

void explore_letter(Uint32* pixels, int width, int height, int x, int y, int** visited, SDL_Rect* bounds, SDL_PixelFormat* format) {
    SDL_Rect queue[2048];
    int queue_size = 0;

    queue[queue_size++] = (SDL_Rect){x, y, 0, 0};
    visited[y][x] = 1;
    bounds->x = x;
    bounds->y = y;
    bounds->w = 1;
    bounds->h = 1;

    while (queue_size > 0) {
        SDL_Rect current = queue[--queue_size];

        if (current.x < bounds->x) bounds->x = current.x;
        if (current.x > bounds->x + bounds->w - 1) bounds->w = current.x - bounds->x + 1;
        if (current.y < bounds->y) bounds->y = current.y;
        if (current.y > bounds->y + bounds->h - 1) bounds->h = current.y - bounds->y + 1;

        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                if (dx == 0 && dy == 0) continue;
                int new_x = current.x + dx;
                int new_y = current.y + dy;

                if (new_x >= 0 && new_x < width && new_y >= 0 && new_y < height) {
                    if (is_black_pixel(pixels[new_y * width + new_x], format) && !visited[new_y][new_x]) {
                        visited[new_y][new_x] = 1;
                        queue[queue_size++] = (SDL_Rect){new_x, new_y, 0, 0};
                    }
                }
            }
        }
    }
}

void draw_letters_combined(SDL_Surface* surface, Point** centers, int* centers_count, SDL_Rect** letters, int* letters_count, int start_x, int start_y, int width, int height) {
    Uint32* pixels = (Uint32*)surface->pixels;
    SDL_LockSurface(surface);
    
    SDL_PixelFormat* format = surface->format;
    int** visited = (int**)malloc(height * sizeof(int*));
    for (int y = 0; y < height; y++) {
        visited[y] = (int*)calloc(width, sizeof(int));
    }

    SDL_Rect temp_letters[2048];
    int temp_count = 0;

    int end_x = start_x + width;
    int end_y = start_y + height;

    for (int y = start_y; y < end_y && y < surface->h; y++) {
        for (int x = start_x; x < end_x && x < surface->w; x++) {
            if (is_black_pixel(pixels[y * surface->w + x], format) && !visited[y - start_y][x - start_x]) {
                SDL_Rect bounds;
                explore_letter(pixels, surface->w, surface->h, x, y, visited, &bounds, format);

                if (bounds.w >= LETTER_MIN_WIDTH && bounds.w <= LETTER_MAX_WIDTH && bounds.h > 0) {
                    temp_letters[temp_count++] = bounds;

                    Uint32 red = SDL_MapRGB(surface->format, 255, 0, 0);
                    draw_empty_rect(surface, bounds, red);
                }
            }
        }

        if (temp_count > 0) {
            int min_x = temp_letters[0].x;
            int max_x = temp_letters[0].x + temp_letters[0].w;
            int min_y = temp_letters[0].y;
            int max_y = temp_letters[0].y + temp_letters[0].h;

            for (int i = 1; i < temp_count; i++) {
                if (abs(temp_letters[i].y - min_y) <= MAX_VERTICAL_DISTANCE && abs(temp_letters[i].x - (temp_letters[i - 1].x + temp_letters[i - 1].w)) <= MAX_LETTER_SPACING) {
                    if (temp_letters[i].x < min_x) {
                        min_x = temp_letters[i].x;
                    }
                    if (temp_letters[i].x + temp_letters[i].w > max_x) {
                        max_x = temp_letters[i].x + temp_letters[i].w;
                    }
                    if (temp_letters[i].y < min_y) {
                        min_y = temp_letters[i].y;
                    }
                    if (temp_letters[i].y + temp_letters[i].h > max_y) {
                        max_y = temp_letters[i].y + temp_letters[i].h;
                    }
                } else {
                    SDL_Rect combined_bounds = {min_x - 2, min_y - 2, (max_x - min_x) + 4, (max_y - min_y) + 4};
                    if (combined_bounds.x >= start_x && combined_bounds.x + combined_bounds.w <= end_x &&
                        combined_bounds.y >= start_y && combined_bounds.y + combined_bounds.h <= end_y) {
                        Uint32 yellow = SDL_MapRGB(surface->format, 255, 255, 0);
                        draw_empty_rect(surface, combined_bounds, yellow);
                    }
                    min_x = temp_letters[i].x;
                    max_x = temp_letters[i].x + temp_letters[i].w;
                    min_y = temp_letters[i].y;
                    max_y = temp_letters[i].y + temp_letters[i].h;
                }
            }
            SDL_Rect combined_bounds = {min_x - 2, min_y - 2, (max_x - min_x) + 4, (max_y - min_y) + 4};
            if (combined_bounds.x >= start_x && combined_bounds.x + combined_bounds.w <= end_x &&
                combined_bounds.y >= start_y && combined_bounds.y + combined_bounds.h <= end_y) {
                Uint32 yellow = SDL_MapRGB(surface->format, 255, 255, 0);
                draw_empty_rect(surface, combined_bounds, yellow);
            }
        }

        temp_count = 0;
    }

    for (int y = 0; y < height; y++) {
        free(visited[y]);
    }
    free(visited);

    SDL_UnlockSurface(surface);
}

int main(int argc, char* argv[]) {
    if (argc != 6) {
        fprintf(stderr, "Usage: %s <image_file> <start_x> <start_y> <width> <height>\n", argv[0]);
        return 1;
    }

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Surface* img = IMG_Load(argv[1]);
    if (!img) {
        fprintf(stderr, "IMG_Load Error: %s\n", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    int start_x = atoi(argv[2]);
    int start_y = atoi(argv[3]);
    int width = atoi(argv[4]);
    int height = atoi(argv[5]);

    Point* centers = NULL;
    int centers_count = 0;
    SDL_Rect* letters = NULL;
    int letters_count = 0;

    draw_letters_combined(img, &centers, &centers_count, &letters, &letters_count, start_x, start_y, width, height);

    if (IMG_SavePNG(img, "output.png") != 0) {
        fprintf(stderr, "IMG_SavePNG Error: %s\n", IMG_GetError());
    }

    SDL_FreeSurface(img);
    SDL_Quit();
    return 0;
}

