#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <err.h>

Uint32 pixel_to_black_or_white(Uint32 pixel_color, SDL_PixelFormat *format, Uint8 threshold) {
    Uint8 r, g, b;
    SDL_GetRGB(pixel_color, format, &r, &g, &b);
    
    // Convert to grayscale using weighted formula
    Uint8 gray = (Uint8)(0.3 * r + 0.59 * g + 0.11 * b);
    
    // Apply threshold to get black or white value
    Uint8 value = gray > threshold ? 255 : 0;
    return SDL_MapRGB(format, value, value, value);
}

void surface_to_blackwhite(SDL_Surface *input_surface, SDL_Surface *output_surface, Uint8 threshold) {
    if (input_surface == NULL || output_surface == NULL) {
        fprintf(stderr, "Surface is NULL: %s\n", SDL_GetError());
        return;
    }

    if (SDL_LockSurface(input_surface) != 0 || SDL_LockSurface(output_surface) != 0) {
        fprintf(stderr, "Failed to lock surface: %s\n", SDL_GetError());
        return;
    }

    SDL_PixelFormat *format = input_surface->format;
    Uint32 *input_pixels = (Uint32 *)input_surface->pixels;
    Uint32 *output_pixels = (Uint32 *)output_surface->pixels;
    int width = input_surface->w;
    int height = input_surface->h;

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            Uint32 pixel_color = input_pixels[(y * width) + x];
            Uint32 bw_pixel = pixel_to_black_or_white(pixel_color, format, threshold);
            output_pixels[(y * width) + x] = bw_pixel;
        }
    }

    SDL_UnlockSurface(input_surface);
    SDL_UnlockSurface(output_surface);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        errx(1, "Usage: %s <input_image> <threshold>", argv[0]);
    }

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        errx(1, "SDL_Init Error: %s", SDL_GetError());
    }

    IMG_Init(IMG_INIT_PNG);

    SDL_Surface *input_image = IMG_Load(argv[1]);
    if (!input_image) {
        errx(1, "IMG_Load Error: %s", IMG_GetError());
    }

    // Create a new surface for the output
    SDL_Surface *output_image = SDL_CreateRGBSurface(0, input_image->w, input_image->h, 32,
                                                     input_image->format->Rmask, input_image->format->Gmask,
                                                     input_image->format->Bmask, input_image->format->Amask);
    if (!output_image) {
        errx(1, "SDL_CreateRGBSurface Error: %s", SDL_GetError());
    }

    Uint8 threshold = (Uint8)atoi(argv[2]);
    surface_to_blackwhite(input_image, output_image, threshold);

    // Generate output filename
    char output_filename[256];
    snprintf(output_filename, sizeof(output_filename), "%s_output.png", argv[1]);

    // Save the transformed image as PNG
    if (IMG_SavePNG(output_image, output_filename) != 0) {
        errx(1, "IMG_SavePNG Error: %s", IMG_GetError());
    }

    printf("Image saved as %s\n", output_filename);

    SDL_FreeSurface(input_image);
    SDL_FreeSurface(output_image);
    IMG_Quit();
    SDL_Quit();

    return 0;
}
