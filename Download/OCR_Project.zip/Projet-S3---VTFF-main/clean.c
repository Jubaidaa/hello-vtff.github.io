#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// image to grayscale
void to_grayscale(SDL_Surface *surface) 
{
    Uint32 *pixels = (Uint32 *)surface->pixels;
    for (int i = 0; i < surface->w * surface->h; i++) 
    {
        Uint8 r, g, b;
        SDL_GetRGB(pixels[i], surface->format, &r, &g, &b);
        Uint8 gray = (Uint8)(0.299 * r + 0.587 * g + 0.114 * b);
        pixels[i] = SDL_MapRGB(surface->format, gray, gray, gray);
    }
}
// Fonction pour appliquer un flou gaussien
void gaussian_blur(SDL_Surface *surface) {
    int width = surface->w;
    int height = surface->h;
    Uint32 *pixels = (Uint32 *)surface->pixels;
    Uint32 *copy = (Uint32 *)malloc(sizeof(Uint32) * width * height);

    if (!copy) {
        printf("Échec de l'allocation mémoire\n");
        return;
    }

    memcpy(copy, pixels, sizeof(Uint32) * width * height);

    // Noyau gaussien 5x5
    double kernel[5][5] = {
        {1,  4,  6,  4, 1},
        {4, 16, 24, 16, 4},
        {6, 24, 36, 24, 6},
        {4, 16, 24, 16, 4},
        {1,  4,  6,  4, 1}
    };
    double kernel_sum = 256; // Somme des éléments du noyau

    // Appliquer le flou gaussien
    for (int y = 2; y < height - 2; y++) {
        for (int x = 2; x < width - 2; x++) {
            double sum = 0.0;
            for (int ky = -2; ky <= 2; ky++) {
                for (int kx = -2; kx <= 2; kx++) {
                    Uint8 r, g, b;
                    SDL_GetRGB(copy[(y + ky) * width + (x + kx)], surface->format, &r, &g, &b);
                    sum += kernel[ky + 2][kx + 2] * r;
                }
            }
            Uint8 value = (Uint8)(sum / kernel_sum);
            pixels[y * width + x] = SDL_MapRGB(surface->format, value, value, value);
        }
    }

    free(copy);
}

// Fonction pour binariser l'image de manière adaptative
void adaptive_binarize(SDL_Surface *surface, int blockSize, double C) {
    int width = surface->w;
    int height = surface->h;
    Uint32 *pixels = (Uint32 *)surface->pixels;
    Uint8 *gray_values = (Uint8 *)malloc(width * height);

    // Récupérer les valeurs en niveaux de gris
    for (int i = 0; i < width * height; i++) {
        Uint8 r, g, b;
        SDL_GetRGB(pixels[i], surface->format, &r, &g, &b);
        gray_values[i] = r; // Comme l'image est en niveaux de gris, r = g = b
    }

    // Appliquer la binarisation adaptative
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int x_start = x - blockSize / 2;
            int x_end = x + blockSize / 2;
            int y_start = y - blockSize / 2;
            int y_end = y + blockSize / 2;

            // Limiter la fenêtre aux bords de l'image
            if (x_start < 0) x_start = 0;
            if (x_end >= width) x_end = width - 1;
            if (y_start < 0) y_start = 0;
            if (y_end >= height) y_end = height - 1;

            // Calculer la moyenne locale
            int sum = 0;
            int count = 0;
            for (int j = y_start; j <= y_end; j++) {
                for (int i = x_start; i <= x_end; i++) {
                    sum += gray_values[j * width + i];
                    count++;
                }
            }
            double mean = sum / (double)count;

            // Appliquer le seuil adaptatif
            Uint8 value = gray_values[y * width + x];
            Uint8 bw = (value > mean - C) ? 255 : 0;
            pixels[y * width + x] = SDL_MapRGB(surface->format, bw, bw, bw);
        }
    }

    free(gray_values);
}


// sharpening filter
void sharpen(SDL_Surface *surface) 
{
    //get_dimensions()
    int width = surface->w;
    int height = surface->h;
    Uint32 *pixels = (Uint32 *)surface->pixels;
    Uint32 *copy = (Uint32 *)malloc(sizeof(Uint32) * width * height);

    if (!copy) 
    {
        printf("Malloc failed\n");
        return;
    }

    memcpy(copy, pixels, sizeof(Uint32) * width * height);

    // kernel
    int kernel[3][3] = 
    {
        {  0, -1,  0 },
        { -1,  5, -1 },
        {  0, -1,  0 }
    };

    // for each pixel in img
    for (int y = 1; y < height - 1; y++) 
    {
        for (int x = 1; x < width -1; x++) 
        {
            int sum = 0;
            // kernel to pixel
            for (int ky = -1; ky <=1; ky++) 
            {
                for (int kx = -1; kx <=1; kx++) 
                {
                    Uint8 r, g, b;
                    SDL_GetRGB(copy[(y + ky) * width + (x + kx)], surface->format, &r, &g, &b);
                    sum += kernel[ky +1][kx +1] * r; // Since it's grayscale, r=g=b
                }
            }
            // clamp 
            if (sum < 0) sum = 0;
            if (sum > 255) sum = 255;
            Uint32 pixel = SDL_MapRGB(surface->format, (Uint8)sum, (Uint8)sum, (Uint8)sum);
            pixels[y * width + x] = pixel;
        }
    }
    free(copy);
}



int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("Le README existe...\n");
        return EXIT_FAILURE;
    }

    const char* img_path = argv[1];

    // init sdl2 & co

    if (SDL_Init(SDL_INIT_VIDEO) != 0)
    {
        SDL_Log("SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }

   
    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG))
    {
        SDL_Log("IMG_Init Error: %s\n", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    
    SDL_Surface *image_surface = IMG_Load(img_path);
    if (!image_surface)
    {
        SDL_Log("IMG_Load Error for %s: %s. PNG ONLY!\n", img_path, IMG_GetError());
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    
    SDL_Window *window = SDL_CreateWindow(
        "Ratman is back with Vikala!",
        SDL_WINDOWPOS_UNDEFINED,
        SDL_WINDOWPOS_UNDEFINED,
        image_surface->w,
        image_surface->h,
        SDL_WINDOW_HIDDEN
    );
    if (!window)
    {
        SDL_Log("SDL_CreateWindow Error: %s\n", SDL_GetError());
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if (!renderer)
    {
        SDL_Log("SDL_CreateRenderer Error: %s\n", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // image to 32-bit format 
    SDL_Surface *formatted_image = SDL_ConvertSurfaceFormat(image_surface, SDL_PIXELFORMAT_ARGB8888, 0);
    SDL_FreeSurface(image_surface);
    if (!formatted_image)
    {
        SDL_Log("SDL_ConvertSurfaceFormat Error: %s\n", SDL_GetError());
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // mrc qui ?
    to_grayscale(formatted_image);
    gaussian_blur(formatted_image);
    sharpen(formatted_image);
    adaptive_binarize(formatted_image, 15, 10.0);

    if (IMG_SavePNG(formatted_image, img_path) != 0)
    {
        SDL_Log("Read-only ton PC ? : %s\n", IMG_GetError());
    }
    else
    {
        printf("Regarde '%s' et profite.\n", img_path);
    }

    // Enleve tes conneries
    SDL_FreeSurface(formatted_image);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();

    return 0;
}
