#include <stdio.h>
#include <math.h>

#define MAX_GRID_SIZE 100 // nombre de char max par ligne (dont le '0\)

typedef struct 
{
    int x;
    int y;
} Position;

char grid[MAX_GRID_SIZE][MAX_GRID_SIZE];
int rows = 0;
int cols = 0;


// On considere que le txt est que de maj 
void to_uppercase(char *str) 
{
    for (; *str; ++str) {
        if (*str >= 'a' && *str <= 'z') {
            *str -= 32;
        }
    }
}


int load_grid(const char *filename) 
{
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        fprintf(stderr, "Error opening grid file\n"); // error basic 
        return -1;
    }

    char line[MAX_GRID_SIZE];
    while (fgets(line, sizeof(line), fp)) 
    {
        size_t len = 0;
        while (line[len] != '\n' && line[len] != '\0' && len < MAX_GRID_SIZE) {
            len++;
        }
        line[len] = '\0';

        if (len > cols)
            cols = len;

        to_uppercase(line);

        for (int i = 0; i < len; i++) 
        {
            grid[rows][i] = line[i];
        }
        grid[rows][len] = '\0';
        rows++;
    }
    fclose(fp);
    return 0;
}

int search_direction(int x, int y, int dx, int dy, const char *word, Position *start, Position *end) {
    int len = 0;
    // longeur mot
    while (word[len] != '\0') len++;
    //for char in mot 
    for (int i = 0; i < len; i++) 
    {   
        int nx = x + i * dx; // pls kill me
        int ny = y + i * dy; // positon du prochain 

        if (nx < 0 || ny < 0 || ny >= rows || nx >= MAX_GRID_SIZE || grid[ny][nx] == '\0') // if out of bounds
            return 0;

        if (grid[ny][nx] != word[i]) // la magie noir (if mot found)
            return 0;
    }
    // if found, reset pos 
    start->x = x;
    start->y = y;
    end->x = x + (len - 1) * dx;
    end->y = y + (len - 1) * dy;
    return 1; // nathan est content, ca compile
}

int main(int argc, char *argv[]) 
{
    if (argc != 3) {
        fprintf(stderr, "Usage: ./solver grid_file word\n");
        return 1;
    }

    const char *grid_file = argv[1];
    char word[MAX_GRID_SIZE];
    int word_len = 0;
    while (argv[2][word_len] != '\0' && word_len < MAX_GRID_SIZE - 1) {
        word[word_len] = argv[2][word_len];
        word_len++;
    }
    word[word_len] = '\0';

    to_uppercase(word);

    if (load_grid(grid_file) != 0) {
        return 1;
    }

    Position start, end;
    int found = 0;

    int directions[8][2] = {
        {1, 0},   // Right
        {0, 1},   // Down
        {-1, 0},  // Left
        {0, -1},  // Up
        {1, 1},   // Diagonal down-right
        {-1, -1}, // Diagonal up-left
        {1, -1},  // Diagonal up-right
        {-1, 1}   // Diagonal down-left
    };

    for (int y = 0; y < rows; y++) {
        int row_len = 0;
        while (grid[y][row_len] != '\0') row_len++;
        for (int x = 0; x < row_len; x++) {
            for (int d = 0; d < 8; d++) {
                if (search_direction(x, y, directions[d][0], directions[d][1], word, &start, &end)) {
                    printf("(%d,%d)(%d,%d)\n", start.x, start.y, end.x, end.y);
                    found = 1;
                    return 0;
                }
            }
        }
    }

    if (!found) {
        printf("Not Found\n");
    }

    return 0;
}
