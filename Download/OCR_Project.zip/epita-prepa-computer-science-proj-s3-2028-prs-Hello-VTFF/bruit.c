#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void to_grayscale(SDL_Surface *surface) {
    Uint32 *pixels = (Uint32 *)surface->pixels;
    for (int i = 0; i < surface->w * surface->h; i++) {
        Uint8 r, g, b;
        SDL_GetRGB(pixels[i], surface->format, &r, &g, &b);
        Uint8 gray = (Uint8)(0.299 * r + 0.587 * g + 0.114 * b);
        pixels[i] = SDL_MapRGB(surface->format, gray, gray, gray);
    }
}

void gaussian_blur(SDL_Surface *surface) {
    int width = surface->w;
    int height = surface->h;
    Uint32 *pixels = (Uint32 *)surface->pixels;
    Uint32 *copy = (Uint32 *)malloc(sizeof(Uint32) * width * height);

    if (!copy) {
        printf("Error of Allocation Memory.\n");
        return;
    }

    memcpy(copy, pixels, sizeof(Uint32) * width * height);

    double kernel[5][5] = {
        {1,  4,  6,  4, 1},
        {4, 16, 24, 16, 4},
        {6, 24, 36, 24, 6},
        {4, 16, 24, 16, 4},
        {1,  4,  6,  4, 1}
    };
    double kernel_sum = 256.0;

    for (int y = 2; y < height - 2; y++) {
        for (int x = 2; x < width - 2; x++) {
            double sum = 0.0;
            for (int ky = -2; ky <= 2; ky++) {
                for (int kx = -2; kx <= 2; kx++) {
                    Uint8 r, g, b;
                    SDL_GetRGB(copy[(y + ky) * width + (x + kx)],
                               surface->format, &r, &g, &b);
                    sum += kernel[ky + 2][kx + 2] * r;
                }
            }
            Uint8 value = (Uint8)(sum / kernel_sum);
            pixels[y * width + x] =
                SDL_MapRGB(surface->format, value, value, value);
        }
    }

    free(copy);
}

void adaptive_binarize(SDL_Surface *surface, int blockSize, double C) {
    int width = surface->w;
    int height = surface->h;
    Uint32 *pixels = (Uint32 *)surface->pixels;
    Uint8 *gray_values = (Uint8 *)malloc(width * height);

    if (!gray_values) {
        printf("Error of Allocation Memory.\n");
        return;
    }

    for (int i = 0; i < width * height; i++) {
        Uint8 r, g, b;
        SDL_GetRGB(pixels[i], surface->format, &r, &g, &b);
        gray_values[i] = r;
    }

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int x_start = x - blockSize / 2;
            int x_end = x + blockSize / 2;
            int y_start = y - blockSize / 2;
            int y_end = y + blockSize / 2;

            if (x_start < 0) x_start = 0;
            if (x_end >= width) x_end = width - 1;
            if (y_start < 0) y_start = 0;
            if (y_end >= height) y_end = height - 1;

            int sum = 0;
            int count = 0;
            for (int j = y_start; j <= y_end; j++) {
                for (int i = x_start; i <= x_end; i++) {
                    sum += gray_values[j * width + i];
                    count++;
                }
            }
            double mean = sum / (double)count;

            Uint8 value = gray_values[y * width + x];
            Uint8 bw = (value > mean - C) ? 255 : 0;
            pixels[y * width + x] = SDL_MapRGB(surface->format, bw, bw, bw);
        }
    }

    free(gray_values);
}

void remove_noise_by_connected_components(SDL_Surface *surface, int min_component_size) {
    int width = surface->w;
    int height = surface->h;
    Uint32 *pixels = (Uint32 *)surface->pixels;

    int *labels = (int *)calloc(width * height, sizeof(int));
    if (!labels) {
        printf("Error of Allocation Memory.\n");
        return;
    }

    int label = 1;
    int max_labels = width * height / 2; 
    int *label_sizes = (int *)calloc(max_labels, sizeof(int));
    if (!label_sizes) {
        printf("Error of Allocation Memory.\n");
        free(labels);
        return;
    }

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int index = y * width + x;
            if (labels[index] == 0) {
                Uint8 r, g, b;
                SDL_GetRGB(pixels[index], surface->format, &r, &g, &b);
                if (r == 0) { 
                    int stack_size = width * height;
                    int *stack = (int *)malloc(stack_size * sizeof(int));
                    if (!stack) {
                        printf("Error of Allocation Memory.\n");
                        free(labels);
                        free(label_sizes);
                        return;
                    }
                    int stack_index = 0;
                    stack[stack_index++] = index;
                    labels[index] = label;
                    int component_size = 0;

                    while (stack_index > 0) {
                        int current = stack[--stack_index];
                        int cx = current % width;
                        int cy = current / width;
                        component_size++;

                        for (int ny = cy - 1; ny <= cy + 1; ny++) {
                            for (int nx = cx - 1; nx <= cx + 1; nx++) {
                                if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                                    int neighbor_index = ny * width + nx;
                                    if (labels[neighbor_index] == 0) {
                                        Uint8 nr, ng, nb;
                                        SDL_GetRGB(pixels[neighbor_index], surface->format, &nr, &ng, &nb);
                                        if (nr == 0) {
                                            labels[neighbor_index] = label;
                                            stack[stack_index++] = neighbor_index;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    free(stack);

                    label_sizes[label] = component_size;
                    label++;

                    if (label >= max_labels) {
                        printf("Nombre maximum de labels atteint\n");
                        free(labels);
                        free(label_sizes);
                        return;
                    }
                }
            }
        }
    }

    for (int i = 0; i < width * height; i++) {
        int lbl = labels[i];
        if (lbl > 0 && label_sizes[lbl] < min_component_size) {
            pixels[i] = SDL_MapRGB(surface->format, 255, 255, 255);
        }
    }

    free(labels);
    free(label_sizes);
}

void get_base_filename(const char *path, char *base_name) {
    const char *dot = strrchr(path, '.');
    if (dot) {
        size_t len = dot - path;
        strncpy(base_name, path, len);
        base_name[len] = '\0';
    } else {
        strcpy(base_name, path); 
    }
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s <image_path> <threshold>\n", argv[0]);
        return EXIT_FAILURE;
    }

    const char *img_path = argv[1];
    int threshold = atoi(argv[2]);

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        SDL_Log("SDL_Init Error: %s\n", SDL_GetError());
        return EXIT_FAILURE;
    }

    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        SDL_Log("IMG_Init Error: %s\n", IMG_GetError());
        SDL_Quit();
        return EXIT_FAILURE;
    }

    SDL_Surface *image_surface = IMG_Load(img_path);
    if (!image_surface) {
        SDL_Log("IMG_Load error for %s : %s\n", img_path, IMG_GetError());
        IMG_Quit();
        SDL_Quit();
        return EXIT_FAILURE;
    }

    SDL_Surface *formatted_image = SDL_ConvertSurfaceFormat(
        image_surface, SDL_PIXELFORMAT_ARGB8888, 0);
    SDL_FreeSurface(image_surface);
    if (!formatted_image) {
        SDL_Log("SDL_ConvertSurfaceFormat Error : %s\n", SDL_GetError());
        IMG_Quit();
        SDL_Quit();
        return EXIT_FAILURE;
    }

    to_grayscale(formatted_image);
    gaussian_blur(formatted_image);
    adaptive_binarize(formatted_image, 9, 5.0);

    remove_noise_by_connected_components(formatted_image, threshold); 

    char base_name[256];
    get_base_filename(img_path, base_name);
    char output_filename[512];
    snprintf(output_filename, sizeof(output_filename), "%s_noise.png", base_name);

    if (IMG_SavePNG(formatted_image, output_filename) != 0) {
        SDL_Log("Save error : %s\n", IMG_GetError());
    } else {
        printf("Save as '%s'.\n", output_filename);
    }

    SDL_FreeSurface(formatted_image);
    IMG_Quit();
    SDL_Quit();

    return EXIT_SUCCESS;
}

