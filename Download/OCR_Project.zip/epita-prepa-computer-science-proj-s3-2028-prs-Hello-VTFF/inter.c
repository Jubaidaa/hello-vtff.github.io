#include <gtk/gtk.h>
#include <err.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

GtkWidget *notebook;
GtkComboBoxText *combo_box_text;
GtkComboBoxText *combo_rotate_text;
GtkWidget *gcc_button;
gboolean last_action_separer_Sandro = FALSE;
//gboolean last_action_manuelSolv = FALSE;
GtkWidget *solver_button;
int maskThresold;
int rotate;
//GtkComboBoxText *combo_box_text; // Combo box pour les images normales
//GtkComboBoxText *extracted_images_combo_box;
GtkComboBoxText *combo_box_text_current_dir;
const int IMAGE_WIDTH = 1000;
const int IMAGE_HEIGHT = 1000;
char saved_expression[256] = {0};

double r_value = 0.0, g_value = 0.0, b_value = 0.0;

double calculate_expression(double r, double g, double b) {
    return 0.3 * r + 0.59 * g + 0.11 * b;
}

void show_calculator_dialog(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *r_entry, *g_entry, *b_entry;
    GtkDialogFlags flags = GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT;

    dialog = gtk_dialog_new_with_buttons("Enter values for r, g, b :",
                                         GTK_WINDOW(data),
                                         flags,
                                         "_Calculate masking",
                                         GTK_RESPONSE_OK,
                                         "_Cancel",
                                         GTK_RESPONSE_CANCEL,
                                         NULL);

    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));

    r_entry = gtk_entry_new();
    g_entry = gtk_entry_new();
    b_entry = gtk_entry_new();

    gtk_entry_set_placeholder_text(GTK_ENTRY(r_entry), "Enter r");
    gtk_entry_set_placeholder_text(GTK_ENTRY(g_entry), "Enter g");
    gtk_entry_set_placeholder_text(GTK_ENTRY(b_entry), "Enter b");

    gtk_box_pack_start(GTK_BOX(content_area), r_entry, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(content_area), g_entry, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(content_area), b_entry, FALSE, FALSE, 0);

    gtk_widget_show_all(dialog);

    gint response = gtk_dialog_run(GTK_DIALOG(dialog));
    if (response == GTK_RESPONSE_OK) {
        const gchar *r_text = gtk_entry_get_text(GTK_ENTRY(r_entry));
        const gchar *g_text = gtk_entry_get_text(GTK_ENTRY(g_entry));
        const gchar *b_text = gtk_entry_get_text(GTK_ENTRY(b_entry));

        r_value = atof(r_text);
        g_value = atof(g_text);
        b_value = atof(b_text);
    }

    gtk_widget_destroy(dialog);
}

void show_result_dialog(GtkWidget *widget, gpointer data) {
    double result = calculate_expression(r_value, g_value, b_value);

    char result_str[256];
    snprintf(result_str, sizeof(result_str), "Result: %.2f", result);
    GtkWidget *result_dialog = gtk_message_dialog_new(GTK_WINDOW(data),
                                                      GTK_DIALOG_MODAL,
                                                      GTK_MESSAGE_INFO,
                                                      GTK_BUTTONS_OK,
                                                      "%s", result_str);
    gtk_dialog_run(GTK_DIALOG(result_dialog));
    gtk_widget_destroy(result_dialog);
}

int file_exists(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file) {
        fclose(file);
        return 1;
    }
    return 0;
}

void load_image(const char *filename, GtkWidget *image) {
    GdkPixbuf *pixbuf = gdk_pixbuf_new_from_file_at_scale(filename, IMAGE_WIDTH, IMAGE_HEIGHT, TRUE, NULL);
    if (pixbuf) {
        gtk_image_set_from_pixbuf(GTK_IMAGE(image), pixbuf);
        g_object_unref(pixbuf);
    } else {
        printf("Error while loading the image : %s\n", filename);
    }
}

void create_image_tab(const char *filename) {
    GtkWidget *image = gtk_image_new();
    GtkWidget *scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(scrolled_window), image);
    load_image(filename, image);

    char *tab_label_text = g_path_get_basename(filename);
    GtkWidget *tab_label = gtk_label_new(tab_label_text);
    g_free(tab_label_text);

    gint page_num = gtk_notebook_append_page(GTK_NOTEBOOK(notebook), scrolled_window, tab_label);
    gtk_widget_show_all(scrolled_window);
    gtk_notebook_set_current_page(GTK_NOTEBOOK(notebook), page_num);
}

void on_combo_changed(GtkComboBox *combo, gpointer user_data) {
    const char *selected_file = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(combo));
    if (selected_file) {
        char filepath[1024];
        snprintf(filepath, sizeof(filepath), "%s/%s", (char *)user_data, selected_file);
        create_image_tab(filepath);

        gtk_widget_hide(gcc_button);
        last_action_separer_Sandro = FALSE;
    }
}
void on_combo_current_dir_changed(GtkComboBox *combo, gpointer user_data) {
         const char *selected_file = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(combo));
    if (selected_file) {
        char filepath[2048];
        snprintf(filepath, sizeof(filepath), "%s/%s", (char *)user_data, selected_file);
        GtkWidget *image = gtk_image_new(); 
        load_image(filepath, image);
        GtkWidget *scrolled_window = gtk_scrolled_window_new(NULL, NULL);
        gtk_container_add(GTK_CONTAINER(scrolled_window), image);
        GtkWidget *tab_label = gtk_label_new(selected_file);
        gint page_num = gtk_notebook_append_page(GTK_NOTEBOOK(notebook), scrolled_window, tab_label);
        gtk_widget_show_all(scrolled_window);
        gtk_notebook_set_current_page(GTK_NOTEBOOK(notebook), page_num);
        gtk_widget_hide(gcc_button);
        last_action_separer_Sandro = FALSE;
    }

}

void update_image_with_output(const char *directory, const char *output_filename) {
    char output_file_path[2048];
    snprintf(output_file_path, sizeof(output_file_path), "%s/../%s", directory, output_filename);
    if (file_exists(output_file_path)) {
        create_image_tab(output_file_path);
    } else {
        printf("%s does not exist in %s\n", output_filename, directory);
    }
}

void execute_separer_sans_draw(const char *user_input) {
    const char *selected_file = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(combo_box_text));
    if (selected_file) {
        char command[2048];
        //const char *directory = "/mnt/c/Users/nathl/Desktop/Epita/Cycle préparatoire/Année 2 - SPE/S3/B5/PROJET S3/hmm/interMage";
	char current_dir[1024];
    	if (getcwd(current_dir, sizeof(current_dir)) == NULL) {
        	("Error cannot seize it there!");
    	}	

    	char directory[2048];
    	snprintf(directory, sizeof(directory), "%s/interMage", current_dir);

        if (g_strcmp0(selected_file, "lvl1_img1.png") == 0) {
            snprintf(command, sizeof(command), "gcc -o masquage masquage.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./masquage interMage/lvl1_img1.png %i", maskThresold);
        } else if (g_strcmp0(selected_file, "lvl1_img2.png") == 0) {
            snprintf(command, sizeof(command), "gcc -o masquage masquage.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./masquage interMage/lvl1_img2.png %i", maskThresold);
        } 
	else {
            printf("File not found : %s\n", selected_file);
        }

        int ret = system(command);
        if (ret != 0) {
            printf("Error while exec. gcc or mask\n");
        } else {
	    //lvl1
            if (g_strcmp0(selected_file, "lvl1_img1.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o separer_sans_draw separer_sans_draw.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./separer_sans_draw interMage/lvl1_img1.png_output.png");
            } else if (g_strcmp0(selected_file, "lvl1_img2.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o separer_sans_draw separer_sans_draw.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./separer_sans_draw interMage/lvl1_img2.png_output.png");
            }
	    /*
	    //lvl3
	    else if (g_strcmp0(selected_file, "lvl3_img2.png_output_noise.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o sephaut Separer_haut.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./sephaut interMage/lvl3_img2.png_output_noise.png");
            }
	    else if (g_strcmp0(selected_file, "lvl3_img2.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o sephaut Separer_haut.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./sephaut interMage/lvl3_img2.png");
            }*/
            int ret = system(command);
            if (ret != 0) {
                printf("Error while exec. gcc or separer_sans_draw\n");
            }
            update_image_with_output(directory, "output.png");
            last_action_separer_Sandro = TRUE;
            gtk_widget_show(gcc_button);
        }
    } else {
        printf("Got no file\n");
    }
}

/*void on_file_selected(GtkFileChooserButton *widget, gpointer user_data) {
    const char *selected_file = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(widget));

    if (selected_file) {
        g_print("Fichier sélectionné : %s\n", selected_file);
    }
}


void select_file(GtkWidget *widget, gpointer user_data) {
    GtkWidget *dialog;
    dialog = gtk_file_chooser_dialog_new("Sélectionner un fichier .txt",
                                         GTK_WINDOW(user_data),
                                         GTK_FILE_CHOOSER_ACTION_OPEN,
                                         "_Cancel", GTK_RESPONSE_CANCEL,
                                         "_Open", GTK_RESPONSE_ACCEPT,
                                         NULL);


    GtkFileFilter *filter = gtk_file_filter_new();
    gtk_file_filter_add_pattern(filter, "*.txt");
    gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(dialog), filter);


    if (gtk_dialog_run(GTK_DIALOG(dialog)) == GTK_RESPONSE_ACCEPT) {

        char *filename = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(dialog));
        g_print("Fichier sélectionné : %s\n", filename);
        g_free(filename);
    }

    gtk_widget_destroy(dialog); 
 
}
*/


void execute_separer_image(GtkWidget *widget, gpointer data) {
    const char *selected_file = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(combo_box_text));
    if (selected_file) {
        char command[2048];
        const char *directory = (const char *)data;

	////////////////////////////////////////////////////////////////////////////sepImage////////////////////////////////////////////////////////////////
        if (g_strcmp0(selected_file, "lvl1_img1.png") == 0) {
            snprintf(command, sizeof(command), "gcc -o separer_image separer_image.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./separer_image interMage/lvl1_img1.png");
        } else if (g_strcmp0(selected_file, "lvl1_img2.png") == 0) {
            snprintf(command, sizeof(command), "gcc -o separer_image separer_image.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./separer_image interMage/lvl1_img2.png");
        } else if (g_strcmp0(selected_file, "output_output2.png") == 0) {
            snprintf(command, sizeof(command), "gcc -o separer_image separer_image.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./separer_image interMage/trool.png");
        }
	else if (g_strcmp0(selected_file, "lvl2_img2.png") == 0) {                                                                                                    snprintf(command, sizeof(command), "gcc -o separer_image separer_image.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./separer_image interMage/lvl1_img2.png");
	}

	////////////////////////////////////////////////////////////////////////////sepHaut////////////////////////////////////////////////////////////////
        else if (g_strcmp0(selected_file, "lvl3_img2.png_output_noise.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o sephaut separer_haut.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./sephaut interMage/lvl3_img2.png_output_noise.png");
            }
	 else if (g_strcmp0(selected_file, "lvl3_img1.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o sephaut separer_haut.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./sephaut interMage/lvl3_img1.png");
            }
         else if (g_strcmp0(selected_file, "lvl3_img2.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o sephaut separer_haut.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./sephaut interMage/lvl3_img2.png");
            }

        int ret = system(command);
        if (ret != 0) {
            printf("Error while exec. gcc or separer_image\n");
        } else {
            update_image_with_output(directory, "output.png");
        }
    } else {
        printf("Got no file.\n");
    }
}

void execute_bruit(const char *user_input) {
    const char *selected_file = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(combo_box_text));
    if (selected_file) {
        char command[2048];
        //const char *directory = "/mnt/c/Users/nathl/Desktop/Epita/Cycle préparatoire/Année 2 - SPE/S3/B5/PROJET S3/hmm/interMage";
        char current_dir[1024];
        if (getcwd(current_dir, sizeof(current_dir)) == NULL) {
                ("Error cannot seize it there!");
        }

        char directory[2048];
        snprintf(directory, sizeof(directory), "%s/interMage", current_dir);

        snprintf(command, sizeof(command), "gcc -o masquage masquage.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./masquage interMage/%s %i",selected_file, maskThresold);

        int ret = system(command);
        if (ret != 0) {
            printf("Error while exec. gcc or mask\n");
        } else {
            if (g_strcmp0(selected_file, "lvl2_img2.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o bruit bruit.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./bruit interMage/lvl2_img2.png_output.png 104");
            } else if (g_strcmp0(selected_file, "lvl3_img2.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o bruit bruit.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./bruit interMage/lvl3_img2.png_output.png 40");
            }
	    else{} 
            int ret = system(command);
            if (ret != 0) {
                printf("Error while exec. gcc or noise\n");
            }
            update_image_with_output(directory, "output.png");
            last_action_separer_Sandro = TRUE;
            gtk_widget_show(gcc_button);
        }
    } else {
        printf("Got no file\n");
    }
}

void execute_rotation(const char *user_input) {
    const char *selected_file = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(combo_box_text));
    if (selected_file) {
        char command[1024];
        char current_dir[1024];
        if (getcwd(current_dir, sizeof(current_dir)) == NULL) {
            errx(EXIT_FAILURE, "Erreur lors de l'obtention du répertoire courant");
        }

        char directory[1024];
        snprintf(directory, sizeof(directory), "%s/interMage", current_dir);

        printf("DEBUG: Fichier sélectionné : %s\n", selected_file);
        printf("DEBUG: Répertoire courant : %s/interMage\n", current_dir);

        snprintf(command, sizeof(command), "gcc -o rot rotate.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./rot interMage/%s %i", selected_file, rotate);

        int ret = system(command);
        if (ret != 0) {
            printf("Error while exec. gcc or normal rot.\n");
        } else {
            update_image_with_output(directory, "rotated_result.png");
        }
    } else {
        printf("Got no file.\n");
    }
}

void apply_gcc_rota(const gchar *image_filename) {
    char command[2048];

    snprintf(command, sizeof(command), "gcc -o rot rotation_auto.c -lm -lSDL2  -lSDL2_image && ./rot interMage/%s", image_filename);

    int result = system(command);

    if (result == 0) {
        g_print("GCC command applied successfully on %s\n", image_filename);
    } else {
        g_print("Error executing GCC command\n");
    }
}

void execute_rota_auto(GtkWidget *widget, gpointer user_data) {
    //GtkComboBoxText *combo_box_text = GTK_COMBO_BOX_TEXT(user_data);
    const gchar *selected_image = gtk_combo_box_text_get_active_text(combo_box_text);
    //const gchar *selected_cur = gtk_combo_box_text_get_active_text(combo_box_text_current_dir);
    
    if (selected_image != NULL)
    {
        apply_gcc_rota(selected_image);
    }
    /*else if(selected_cur != NULL)
    {
	    apply_gcc_rota(selected_cur);
    }*/
    else 
    {
        g_print("No image selected!\n");
    }
}

void execute_extraction(GtkWidget *widget, gpointer data) {
    if (last_action_separer_Sandro) {
        char command[2048];
        snprintf(command, sizeof(command), "gcc -o extraction extraction.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./extraction output.png");
        int ret = system(command);
        if (ret != 0) {
            printf("Error with the gcc.\n");
        } else {
                //populate_image_list(combo_box_text, ".");
                printf("It's work kids!\n");
        }
    } else {
        printf("Last action wasn't the detection of the letters only.\n");
    }
}
int string_to_int(const char *str) {
        errno = 0;

    char *endptr;
    long result = strtol(str, &endptr, 10);

    if (*endptr != '\0') {
        printf("Error not valid str.\n");
        return -1;
    }

    if ((result == LONG_MAX || result == LONG_MIN) && errno == ERANGE) {
        printf("overflow or underflow error");
        return -1;
    }

    if (result > INT_MAX || result < INT_MIN) {
        printf("Error: Number does not match.\n");
        return -1;
    }

    return (int)result;
}

void on_entry_dialog_response(GtkDialog *dialog, gint response_id, gpointer user_data) {
    if (response_id == GTK_RESPONSE_OK) {
        GtkWidget *entry = GTK_WIDGET(user_data);
        const char *entry_text = gtk_entry_get_text(GTK_ENTRY(entry));
        maskThresold = string_to_int(entry_text);

        g_print("Value entered : %s\n", entry_text);

        gtk_widget_destroy(GTK_WIDGET(dialog));
	execute_separer_sans_draw(entry_text);
    } else {
        gtk_widget_destroy(GTK_WIDGET(dialog));
    }
}

void show_entry_dialog(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *entry;
    GtkDialogFlags flags = GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT;

    dialog = gtk_dialog_new_with_buttons("Masking!",
                                         GTK_WINDOW(data),
                                         flags,
                                         "_OK",
                                         GTK_RESPONSE_OK,
                                         "_Cancel",
                                         GTK_RESPONSE_CANCEL,
                                         NULL);

    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry), "Masking's value");
    gtk_container_add(GTK_CONTAINER(content_area), entry);

    g_signal_connect(dialog, "response", G_CALLBACK(on_entry_dialog_response), entry);

    gtk_widget_show_all(dialog);
}

void noise_dialog_response(GtkDialog *dialog, gint response_id, gpointer user_data) {
    if (response_id == GTK_RESPONSE_OK) {
        GtkWidget *entry = GTK_WIDGET(user_data);
        const char *entry_text = gtk_entry_get_text(GTK_ENTRY(entry));
        maskThresold = string_to_int(entry_text);

        g_print("Value entered : %s\n", entry_text);

        gtk_widget_destroy(GTK_WIDGET(dialog));
        execute_bruit(entry_text);
    } else {
        gtk_widget_destroy(GTK_WIDGET(dialog));
    }
}

void noise_dialog(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *entry;
    GtkDialogFlags flags = GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT;

    dialog = gtk_dialog_new_with_buttons("Masking!",
                                         GTK_WINDOW(data),
                                         flags,
                                         "_OK",
                                         GTK_RESPONSE_OK,
                                         "_Cancel",
                                         GTK_RESPONSE_CANCEL,
                                         NULL);

    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry), "Masking's value");
    gtk_container_add(GTK_CONTAINER(content_area), entry);

    g_signal_connect(dialog, "response", G_CALLBACK(noise_dialog_response), entry);

    gtk_widget_show_all(dialog);
}

void on_rotation_dialog_response(GtkDialog *dialog, gint response_id, gpointer user_data) {
    if (response_id == GTK_RESPONSE_OK) {
        GtkWidget *entry = GTK_WIDGET(user_data);
        const char *entry_text = gtk_entry_get_text(GTK_ENTRY(entry));
        rotate = atoi(entry_text);

        g_print("Angle of rotation : %s\n", entry_text);

        gtk_widget_destroy(GTK_WIDGET(dialog));
        execute_rotation(entry_text);
    } else {
        gtk_widget_destroy(GTK_WIDGET(dialog));
    }
}

void show_rotation_dialog(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *entry;
    GtkDialogFlags flags = GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT;

    dialog = gtk_dialog_new_with_buttons("Enter rotation angle",
                                         GTK_WINDOW(data),
                                         flags,
                                         "_OK",
                                         GTK_RESPONSE_OK,
                                         "_Cancel",
                                         GTK_RESPONSE_CANCEL,
                                         NULL);

    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry), "Angle of rotation");
    gtk_container_add(GTK_CONTAINER(content_area), entry);

    g_signal_connect(dialog, "response", G_CALLBACK(on_rotation_dialog_response), entry);

    gtk_widget_show_all(dialog);
}

void populate_combo_box(GtkComboBoxText *combo, const char *directory) {
    GDir *dir;
    const gchar *filename;

    dir = g_dir_open(directory, 0, NULL);
    if (dir == NULL) {
        printf("Error with the directory : %s\n", directory);
        return;
    }

    while ((filename = g_dir_read_name(dir)) != NULL) {
        if (g_str_has_suffix(filename, ".png")) {
            gtk_combo_box_text_append_text(combo, filename);
        }
    }

    g_dir_close(dir);
}

void save_text_to_file(const char *filename, const char *text) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error with the file %s for writing", filename);
    }
    fprintf(file, "%s", text);
    fclose(file);
}

void on_save_dialog_response(GtkDialog *dialog, gint response_id, gpointer user_data) {
    if (response_id == GTK_RESPONSE_OK) {
        GtkWidget *text_view = GTK_WIDGET(user_data);
        GtkTextBuffer *buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(text_view));

        GtkTextIter start, end;
        gtk_text_buffer_get_bounds(buffer, &start, &end);
        gchar *text = gtk_text_buffer_get_text(buffer, &start, &end, FALSE);

        char current_dir[1024];
        if (getcwd(current_dir, sizeof(current_dir)) == NULL) {
            printf("Error with the actual point.");
        }

        char filepath[2048];
        snprintf(filepath, sizeof(filepath), "%s/grid.txt", current_dir);

        save_text_to_file(filepath, text);
        g_free(text);

        gtk_widget_show(solver_button);
    }
    gtk_widget_destroy(GTK_WIDGET(dialog));
}

void show_text_input_dialog(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *text_view;
    GtkDialogFlags flags = GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT;

    dialog = gtk_dialog_new_with_buttons("Enter your grid",
                                         GTK_WINDOW(data),
                                         flags,
                                         "_Save",
                                         GTK_RESPONSE_OK,
                                         "_Cancel",
                                         GTK_RESPONSE_CANCEL,
                                         NULL);

    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    text_view = gtk_text_view_new();
    gtk_container_add(GTK_CONTAINER(content_area), text_view);

    g_signal_connect(dialog, "response", G_CALLBACK(on_save_dialog_response), text_view);

    gtk_widget_show_all(dialog);
}

void on_solver_button_clicked(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog, *content_area, *entry;
    GtkDialogFlags flags = GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT;

    dialog = gtk_dialog_new_with_buttons("Search",
                                         GTK_WINDOW(data),
                                         flags,
                                         "_Try",
                                         GTK_RESPONSE_OK,
                                         "_Cancel",
                                         GTK_RESPONSE_CANCEL,
                                         NULL);

    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    entry = gtk_entry_new();
    gtk_container_add(GTK_CONTAINER(content_area), entry);

    gtk_widget_show_all(dialog);

    gint response = gtk_dialog_run(GTK_DIALOG(dialog));
    if (response == GTK_RESPONSE_OK) {
        const gchar *param = gtk_entry_get_text(GTK_ENTRY(entry));
        char command[256];
        snprintf(command, sizeof(command), "gcc -o solver solver.c -Wextra -Wall && ./solver grid.txt %s", param);
        system(command);
    }
    gtk_widget_destroy(dialog);
}

void refresh_combo_boxes(GtkWidget *widget, gpointer data) {
    //const char *current_dir = (const char *)data;
    char current_dir[1024];
    if (getcwd(current_dir, sizeof(current_dir)) == NULL) {
        printf("Error with the refresh current point");
    }

    char directory[2048];
    snprintf(directory, sizeof(directory), "%s/interMage", current_dir);

    gtk_combo_box_text_remove_all(combo_box_text);
    populate_combo_box(combo_box_text, directory);

    //char directory[2048];
    //snprintf(directory, sizeof(directory), "%s/interMage", current_dir);ons
    gtk_combo_box_text_remove_all(combo_box_text_current_dir);
    populate_combo_box(combo_box_text_current_dir, current_dir);
}

void execute_remove_grid(GtkWidget *widget, gpointer data) {
    const char *selected_file = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(combo_box_text));
    if (selected_file) {
        char command[2048];
        const char *directory = (const char *)data;

        if (g_strcmp0(selected_file, "lvl2_img2.png_output_noise.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o remove remove_grid.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./remove interMage/lvl2_img2.png_output_noise.png");
            }
         else if (g_strcmp0(selected_file, "lvl4_img2.png") == 0) {
                snprintf(command, sizeof(command), "gcc -o remove remove_grid.c -lSDL2 -lSDL2_image -lm -Wextra -Wall && ./remove interMage/lvl4_img2.png");
            }

        int ret = system(command);
        if (ret != 0) {
            printf("Error while exec. gcc or remove grid\n");
        } else {
            update_image_with_output(directory, "output.png");
        }
    } else {
        printf("Got no file.\n");
    }
}

int main(int argc, char *argv[]) {
    GtkWidget *window;
    GtkWidget *hbox;
    GtkWidget *vbox;
    GtkWidget *button;
    GtkWidget *button_calculator;
    GtkWidget *button_result;
    GtkWidget *alternative_button;
    char current_dir[1024];
    if (getcwd(current_dir, sizeof(current_dir)) == NULL) {
        printf("Error with the current point.");
    }

    char directory[2048];
    snprintf(directory, sizeof(directory), "%s/interMage", current_dir);

    //const char *directory = "/mnt/c/Users/nathl/Desktop/Epita/Cycle préparatoire/Année 2 - SPE/S3/B5/PROJET S3/hmm/interMage";

    gtk_init(&argc, &argv);

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Interface Hello, VTFF...");
    gtk_window_set_default_size(GTK_WINDOW(window), 800, 600);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_container_add(GTK_CONTAINER(window), hbox);

    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_box_pack_start(GTK_BOX(hbox), vbox, FALSE, FALSE, 0);


    // rotation
    button = gtk_button_new_with_label("Run rotation");
    g_signal_connect(button, "clicked", G_CALLBACK(show_rotation_dialog), (gpointer)window);
    gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);


     //alternative_button = gtk_button_new_with_label("Alternative Processing");
    //g_signal_connect(alternative_button, "clicked", G_CALLBACK(alternative_dialog), box);
    //gtk_box_pack_start(GTK_BOX(box), alternative_button, TRUE, TRUE, 0);
    
    //rota auto
    button = gtk_button_new_with_label("Run auto rotation");
    g_signal_connect(button, "clicked", G_CALLBACK(execute_rota_auto), (gpointer)directory);
    gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);

     // Separer image
    button = gtk_button_new_with_label("Run remove grid");
    g_signal_connect(button, "clicked", G_CALLBACK(execute_remove_grid), (gpointer)directory);
    gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);

    // Separer image
    button = gtk_button_new_with_label("Run separer_image");
    g_signal_connect(button, "clicked", G_CALLBACK(execute_separer_image), (gpointer)directory);
    gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);

    // Separer sans draw
    button = gtk_button_new_with_label("Run letters detection");
    g_signal_connect(button, "clicked", G_CALLBACK(show_entry_dialog), (gpointer)window);
    gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);

    //Noise
    //button = gtk_button_new_with_label("Delete Noise");
    //g_signal_connect(button, "clicked", G_CALLBACK(noise_dialog), (gpointer)window);
    //gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);

    // Extraction
    gcc_button = gtk_button_new_with_label("Run extraction");
    g_signal_connect(gcc_button, "clicked", G_CALLBACK(execute_extraction), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), gcc_button, FALSE, FALSE, 0);
    gtk_widget_hide(gcc_button);
    
     //Noise
    button = gtk_button_new_with_label("Delete Noise");
    g_signal_connect(button, "clicked", G_CALLBACK(noise_dialog), (gpointer)window);
    gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);

    //grid.txt
    button = gtk_button_new_with_label("Enter text");
    g_signal_connect(button, "clicked", G_CALLBACK(show_text_input_dialog), (gpointer)window);
    gtk_box_pack_start(GTK_BOX(vbox), button, FALSE, FALSE, 0);

    //solver manuel
    solver_button = gtk_button_new_with_label("Run solver");
    gtk_widget_set_no_show_all(solver_button, TRUE);
    g_signal_connect(solver_button, "clicked", G_CALLBACK(on_solver_button_clicked), (gpointer)window);
    gtk_box_pack_start(GTK_BOX(vbox), solver_button, FALSE, FALSE, 0);

    //Menu déroulant Image
    combo_box_text = GTK_COMBO_BOX_TEXT(gtk_combo_box_text_new());
    gtk_box_pack_start(GTK_BOX(vbox), GTK_WIDGET(combo_box_text), FALSE, FALSE, 0);
    populate_combo_box(combo_box_text, directory);
    g_signal_connect(combo_box_text, "changed", G_CALLBACK(on_combo_changed), (gpointer)directory);

    //Menu déroulant extraction
    combo_box_text_current_dir = GTK_COMBO_BOX_TEXT(gtk_combo_box_text_new());
    gtk_box_pack_start(GTK_BOX(vbox), GTK_WIDGET(combo_box_text_current_dir), FALSE, FALSE, 0);
    populate_combo_box(combo_box_text_current_dir, current_dir);
    g_signal_connect(combo_box_text_current_dir, "changed", G_CALLBACK(on_combo_current_dir_changed), (gpointer)current_dir);
    notebook = gtk_notebook_new();
    gtk_box_pack_start(GTK_BOX(hbox), notebook, TRUE, TRUE, 0);

    // Ajouter un bouton pour rafraîchir les menus	
    GtkWidget *refresh_button = gtk_button_new_with_label("Refresh !");	
    g_signal_connect(refresh_button, "clicked", G_CALLBACK(refresh_combo_boxes), (gpointer)current_dir);
    gtk_box_pack_start(GTK_BOX(vbox), refresh_button, FALSE, FALSE, 0);
    //set_button_background_color(refresh_button, "#3498db");

    //calcul + res
    button_calculator = gtk_button_new_with_label("Masking value ?");
    g_signal_connect(button_calculator, "clicked", G_CALLBACK(show_calculator_dialog), (gpointer)window);
    gtk_box_pack_start(GTK_BOX(vbox), button_calculator, FALSE, FALSE, 0);
    button_result = gtk_button_new_with_label("Masking answer");
    g_signal_connect(button_result, "clicked", G_CALLBACK(show_result_dialog), (gpointer)window);
    gtk_box_pack_start(GTK_BOX(vbox), button_result, FALSE, FALSE, 0);

    gtk_widget_show_all(window);

    gtk_main();

    return 0;
}
