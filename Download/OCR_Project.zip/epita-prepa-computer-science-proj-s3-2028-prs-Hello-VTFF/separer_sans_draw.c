#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>

#define LETTER_MIN_WIDTH 1
#define LETTER_MAX_WIDTH 50
#define GRID_SPACING 15
#define WORD_SPACING 3
#define THRESOLD 3

typedef struct {
	int x;
	int y;
} Point;

typedef struct {
	int y;
	int first_x;
	int last_x;
} Result;

typedef struct {
    int first;
    int second;
} IntPair;

void extract_color(Uint32 pixel, Uint8* r, Uint8* g, Uint8* b) {
	*r = (pixel >> 16) & 0xFF;
	*g = (pixel >> 8) & 0xFF;
	*b = pixel & 0xFF;
}

int is_black_pixel(Uint32 pixel) {
	Uint8 r, g, b;
	extract_color(pixel, &r, &g, &b);
	return (r < 200 && g < 200 && b < 200);
}

void save_image(const char* filename, SDL_Surface* surface) {
	if (IMG_SavePNG(surface, filename) != 0)
		printf("IMG_SavePNG Error: %s\n", IMG_GetError());
	else
		printf("Image saved as %s\n", filename);
}

void draw_empty_rect(SDL_Surface* surface, SDL_Rect rect, Uint32 color) {
	Uint32* pixels = (Uint32*)surface->pixels;
	int width = surface->w;

	for (int x = rect.x; x < rect.x + rect.w; x++) {
		if (x >= 0 && x < width && rect.y >= 0 && rect.y < surface->h) {
			pixels[rect.y * width + x] = color;
		}
	}

	for (int x = rect.x; x < rect.x + rect.w; x++) {
		if (x >= 0 && x < width && (rect.y + rect.h - 1) >= 0
				&& (rect.y + rect.h - 1) < surface->h) {
			pixels[(rect.y + rect.h - 1) * width + x] = color;
		}
	}

	for (int y = rect.y; y < rect.y + rect.h; y++) {
		if (rect.x >= 0 && rect.x < width && y >= 0 && y < surface->h) {
			pixels[y * width + rect.x] = color;
		}
	}

	for (int y = rect.y; y < rect.y + rect.h; y++) {
		if ((rect.x + rect.w - 1) >= 0 && (rect.x + rect.w - 1) <width
				&& y >= 0 && y < surface->h) {
			pixels[y * width + (rect.x + rect.w - 1)] = color;
		}
	}
}

void explore_letter(Uint32* pixels, int width, int height, int x,
		int y, int visited[][width], SDL_Rect* bounds) {
	SDL_Rect queue[2048];
	int queue_size = 0;

	queue[queue_size++] = (SDL_Rect){ x, y, 0, 0 };
	visited[y][x] = 1;

	bounds->x = x;
	bounds->y = y;
	bounds->w = 1;
	bounds->h = 1;

	while (queue_size > 0) {
		SDL_Rect current = queue[--queue_size];

		if (current.x < bounds->x) bounds->x = current.x;
		if (current.x > bounds->x + bounds->w - 1){
			bounds->w = current.x - bounds->x + 1;
		}
		if (current.y < bounds->y) bounds->y = current.y;
		if (current.y > bounds->y + bounds->h - 1){
			bounds->h = current.y - bounds->y + 1;
		}
		for (int dy = -1; dy <= 1; dy++) {
			for (int dx = -1; dx <= 1; dx++) {
				if (dx == 0 && dy == 0) continue;

				int new_x = current.x + dx;
				int new_y = current.y + dy;

				if (new_x >= 0 && new_x < width && new_y >= 0
						&& new_y < height) {
					if (is_black_pixel(pixels[new_y *width
						+ new_x])
						&&!visited[new_y][new_x]) {
						visited[new_y][new_x] = 1;
						queue[queue_size++] =(SDL_Rect)
						{ new_x, new_y, 0, 0 };
					}
				}
			}
		}
	}
}

int contains(int* list, int list_size, int value) {
	for (int i = 0; i < list_size; i++) {
		if (list[i] == value) {
			return 1;
		}
	}
	return 0;
}

void draw_line_at_center(SDL_Surface* surface, SDL_Rect rect, Uint32 color,
		Point** centers, int* centers_count) {
	Uint32* pixels = (Uint32*)surface->pixels;
	int width = surface->w;
	int center_x = rect.x + rect.w / 2;
	int center_y = rect.y + rect.h / 2;

	for (int y = rect.y; y < rect.y + rect.h; y++) {
		if (center_x >= 0 && center_x < width) {
			pixels[y * width + center_x] = color;
		}
	}


	for (int i = 0; i < *centers_count; i++) {
		if ((*centers)[i].x == center_x
				&& (*centers)[i].y == center_y) {
			return;
		}
	}

	*centers = realloc(*centers, (*centers_count + 1) * sizeof(Point));
	if (*centers) {
		(*centers)[*centers_count].x = center_x;
		(*centers)[*centers_count].y = center_y;
		(*centers_count)++;
	} else {
		printf("Error reallocating memory for centers.\n");
	}
}

void draw_letters(SDL_Surface* surface, Point** centers, int* centers_count) {
	Uint32* pixels = (Uint32*)surface->pixels;
	SDL_LockSurface(surface);

	int visited[surface->h][surface->w];
	for (int y = 0; y < surface->h; y++) {
		for (int x = 0; x < surface->w; x++) {
			visited[y][x] = 0;
		}
	}

	for (int y = 0; y < surface->h; y++) {
		for (int x = 0; x < surface->w; x++) {
			if (is_black_pixel(pixels[y * surface->w + x])
					&& !visited[y][x]) {
				SDL_Rect bounds;
				explore_letter(pixels, surface->w, surface->h,
						x, y, visited, &bounds);

				if (bounds.w >= LETTER_MIN_WIDTH
						&& bounds.w <= LETTER_MAX_WIDTH
						&& bounds.h > 0) {
					Uint32 red = SDL_MapRGB(surface->format
							, 255, 0, 0);
					Uint32 green = SDL_MapRGB(
							surface->format, 
							0, 255, 0);
					draw_empty_rect(surface, bounds, red);
//draw_line_at_center(surface, bounds,green, centers, centers_count);
				}
			}
		}
	}

	SDL_UnlockSurface(surface);
}

int compare_first_x(const void* a, const void* b) {
	Result* resultA = (Result*)a;
	Result* resultB = (Result*)b;
	return resultA->first_x - resultB->first_x;
}

int find_max(int *list, int size) {
    if (size == 0) {
        printf("Empty list\n");
        return -1;
    }

    int max = list[0];
    for (int i = 1; i < size; i++) {
        if (list[i] > max) {
            max = list[i];
        }
    }
    return max;
}

void remove_max(int *list, int *size) {
    if (*size == 0) {
        printf("Empty list\n");
        return;
    }

    int max = find_max(list, *size);
    int found = 0;

    for (int i = 0; i < *size; i++) {
        if (list[i] == max && !found) {
            found = 1;
        }
        if (found && i < *size - 1) {
            list[i] = list[i + 1];
        }
    }

    if (found) {
        (*size)--;
    }
}


void draw_vertical_line(SDL_Surface *surface, int x, int height, Uint32 color){
	if (x < 0 || x >= surface->w) {
		printf("x is out of surface\n");
		return;
	}

	for (int y = 0; y < height; y++) {
		if (y >= 0 && y < surface->h) {
			((Uint32*)surface->pixels)[y * surface->w + x] = color;
		}
	}
}

IntPair generate_first_last_x_list(Point* centers, int centers_count) {
	IntPair result;
	if (centers_count == 0) {
		result.first = -1;
        	result.second = -1;
        	return result;

	}

	Result* results = malloc(centers_count * sizeof(Result));
	if (results == NULL) {
		printf("Unable to allocate memory");
		result.first = -1;
                result.second = -1;
                return result;
	}

	int* found_y = malloc(centers_count * sizeof(int));
	int unique_y_count = 0;

	for (int i = 0; i < centers_count; i++) {
		found_y[i] = -1;
	}

	for (int i = 0; i < centers_count; i++) {
		int y = centers[i].y;
		int x = centers[i].x;

		int found_index = -1;
		for (int j = 0; j < unique_y_count; j++) {
			if (found_y[j] == y) {
				found_index = j;
				break;
			}
		}

		if (found_index == -1) {
			found_index = unique_y_count++;
			found_y[found_index] = y;
			results[found_index].y = y;
			results[found_index].first_x = x;
			results[found_index].last_x = x;
		} else {
			if (x < results[found_index].first_x) {
				results[found_index].first_x = x;
			}
			if (x > results[found_index].last_x) {
				results[found_index].last_x = x;
			}
		}
	}

	qsort(results, unique_y_count, sizeof(Result), compare_first_x);

	printf("\n\nTuple of three pls...\n");

	int acc1 = results[0].first_x;
	int Xplacement;

	int* last_x_list = (int*)malloc(unique_y_count * sizeof(int));
	int last_x_count = 0;

	if (last_x_list == NULL) {
		printf("Unable to allocate memory");
		free(results);
		free(found_y);
		result.first = -1;
                result.second = -1;
                return result;

	}

	for (int i = 0; i < unique_y_count; i++) {
		int first_x = results[i].first_x;
		int last_x = results[i].last_x;
		printf("Y: %d, First X: %d, Last X: %d, diff: %d\n",
				results[i].y,
				first_x,
				last_x,
				last_x - first_x);

		last_x_list[last_x_count] = last_x;
		last_x_count++;

		if (first_x - acc1 > THRESOLD) {
			int max = find_max(last_x_list, last_x_count);
			while(max > first_x)
			{
				remove_max(last_x_list, &last_x_count);
                                max = find_max(last_x_list, last_x_count);
			}
			int tmp = (first_x - max) / 2;
			Xplacement = max + tmp;
			while (Xplacement > first_x && last_x_count > 0) {
				remove_max(last_x_list, &last_x_count);
				max = find_max(last_x_list, last_x_count);
				Xplacement = max + tmp;
			}
			break;
		}
		acc1 = first_x;
	}

	printf("X should be here : %d\n", Xplacement);
	
	free(last_x_list);
	free(results);
	free(found_y);
	
	result.first = Xplacement;
    	result.second = last_x_count;
    	return result;
}

void draw_rectangle(SDL_Surface* img, int x1, int y1,
		int x2, int y2, Uint32 color) {
    SDL_Rect rect;
    rect.x = x1;
    rect.y = y1;
    rect.w = x2 - x1;
    rect.h = y2 - y1;

    SDL_FillRect(img, &rect, color);
}

void encadre_partie_image(SDL_Surface* img, int x, Uint32 color) {
    int width = img->w;
    int height = img->h;

    if (width - x > x) {
        draw_rectangle(img, x, 0, width, height, color);
    } else {
        draw_rectangle(img, 0, 0, x, height, color);
    }
}

int main(int argc, char* argv[]) {
	if (argc != 2) {
		printf("Usage: %s <image_file>\n", argv[0]);
		return 1;
	}

	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		printf("SDL_Init Error: %s\n", SDL_GetError());
		return 1;
	}

	SDL_Surface* img = IMG_Load(argv[1]);
	if (!img) {
		printf("IMG_Load Error: %s\n", IMG_GetError());
		SDL_Quit();
		return 1;
	}

	Point* centers = NULL;
	int centers_count = 0;

	draw_letters(img, &centers, &centers_count);

	save_image("output.png", img);
	printf("Center coordinates (x, y):\n");
	for (int i = 0; i < centers_count; i++) {
		printf("(%d, %d)\n", centers[i].x, centers[i].y);
	}

	IntPair result = generate_first_last_x_list(centers, centers_count);
	int x = result.first;
	int y = result.second;
	Uint32 color = SDL_MapRGB(img->format, 255, 0, 255);
	draw_vertical_line(img, x, img->h, color);
	save_image("output.png", img);
	Uint32 blue = SDL_MapRGB(img->format, 0, 0, 255);
	encadre_partie_image(img, x, blue);
	printf("Test number of words : %d\n", y);
	free(centers);
	SDL_FreeSurface(img);
	SDL_Quit();
	return 0;
}
