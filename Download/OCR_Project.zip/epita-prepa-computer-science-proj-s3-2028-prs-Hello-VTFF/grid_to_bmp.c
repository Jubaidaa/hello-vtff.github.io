#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL2/SDL.h>

#define TAILLE_CASE 40
#define MARGE 2
#define FICHIER_GRILLE "grid_output.txt"
#define NOM_IMAGE "grid_output.bmp"

typedef struct {
    int largeur;
    int hauteur;
    char **cases;
} Grille;

// Taille de la police bitmap
#define FONT_WIDTH  8
#define FONT_HEIGHT 8
#define FONT_SCALE  3
// Tableau contenant la forme de quelques lettres en 8x8 pixels (bitmaps)
// 1 = pixel noir, 0 = pixel blanc
// Chaque ligne est un octet, les bits de poids fort représentent la gauche du caractère
static unsigned char font_data[128][8];

// Initialisation de la police minimale
// On mettra quelques lettres comme 'A', 'B', 'C', 'D' en exemple.
// Vous pouvez ajouter d'autres lettres selon vos besoins.
static void init_font() {
    // Lettre A
    font_data['A'][0] = 0x18; // 00011000
    font_data['A'][1] = 0x24; // 00100100
    font_data['A'][2] = 0x42; // 01000010
    font_data['A'][3] = 0x7E; // 01111110
    font_data['A'][4] = 0x42; // 01000010
    font_data['A'][5] = 0x42; // 01000010
    font_data['A'][6] = 0x42; // 01000010
    font_data['A'][7] = 0x00;

    // B
    font_data['B'][0] = 0x7C; // 01111100
    font_data['B'][1] = 0x42; // 01000010
    font_data['B'][2] = 0x42; // 01000010
    font_data['B'][3] = 0x7C; // 01111100
    font_data['B'][4] = 0x42; // 01000010
    font_data['B'][5] = 0x42; // 01000010
    font_data['B'][6] = 0x7C; // 01111100
    font_data['B'][7] = 0x00;

    // C
    font_data['C'][0] = 0x3C; // 00111100
    font_data['C'][1] = 0x42; // 01000010
    font_data['C'][2] = 0x40; // 01000000
    font_data['C'][3] = 0x40; // 01000000
    font_data['C'][4] = 0x40; // 01000000
    font_data['C'][5] = 0x42; // 01000010
    font_data['C'][6] = 0x3C; // 00111100
    font_data['C'][7] = 0x00;

    // D
    font_data['D'][0] = 0x78; // 01111000
    font_data['D'][1] = 0x44; // 01000100
    font_data['D'][2] = 0x42; // 01000010
    font_data['D'][3] = 0x42; // 01000010
    font_data['D'][4] = 0x42; // 01000010
    font_data['D'][5] = 0x44; // 01000100
    font_data['D'][6] = 0x78; // 01111000
    font_data['D'][7] = 0x00;

    // E
    font_data['E'][0] = 0x7E;
    font_data['E'][1] = 0x40;
    font_data['E'][2] = 0x40;
    font_data['E'][3] = 0x7C;
    font_data['E'][4] = 0x40;
    font_data['E'][5] = 0x40;
    font_data['E'][6] = 0x7E;
    font_data['E'][7] = 0x00;

    // F
    font_data['F'][0] = 0x7E;
    font_data['F'][1] = 0x40;
    font_data['F'][2] = 0x40;
    font_data['F'][3] = 0x7C;
    font_data['F'][4] = 0x40;
    font_data['F'][5] = 0x40;
    font_data['F'][6] = 0x40;
    font_data['F'][7] = 0x00;

    // G
    font_data['G'][0] = 0x3C;
    font_data['G'][1] = 0x42;
    font_data['G'][2] = 0x40;
    font_data['G'][3] = 0x40;
    font_data['G'][4] = 0x4E;
    font_data['G'][5] = 0x42;
    font_data['G'][6] = 0x3C;
    font_data['G'][7] = 0x00;

    // H
    font_data['H'][0] = 0x42;
    font_data['H'][1] = 0x42;
    font_data['H'][2] = 0x42;
    font_data['H'][3] = 0x7E;
    font_data['H'][4] = 0x42;
    font_data['H'][5] = 0x42;
    font_data['H'][6] = 0x42;
    font_data['H'][7] = 0x00;

    // I
    font_data['I'][0] = 0x3C;
    font_data['I'][1] = 0x18;
    font_data['I'][2] = 0x18;
    font_data['I'][3] = 0x18;
    font_data['I'][4] = 0x18;
    font_data['I'][5] = 0x18;
    font_data['I'][6] = 0x3C;
    font_data['I'][7] = 0x00;

    // J
    font_data['J'][0] = 0x1E;
    font_data['J'][1] = 0x04;
    font_data['J'][2] = 0x04;
    font_data['J'][3] = 0x04;
    font_data['J'][4] = 0x04;
    font_data['J'][5] = 0x44;
    font_data['J'][6] = 0x38;
    font_data['J'][7] = 0x00;

    // K
    font_data['K'][0] = 0x42;
    font_data['K'][1] = 0x44;
    font_data['K'][2] = 0x48;
    font_data['K'][3] = 0x70;
    font_data['K'][4] = 0x48;
    font_data['K'][5] = 0x44;
    font_data['K'][6] = 0x42;
    font_data['K'][7] = 0x00;

    // L
    font_data['L'][0] = 0x40;
    font_data['L'][1] = 0x40;
    font_data['L'][2] = 0x40;
    font_data['L'][3] = 0x40;
    font_data['L'][4] = 0x40;
    font_data['L'][5] = 0x40;
    font_data['L'][6] = 0x7E;
    font_data['L'][7] = 0x00;

    // M
    font_data['M'][0] = 0x42;
    font_data['M'][1] = 0x66;
    font_data['M'][2] = 0x5A;
    font_data['M'][3] = 0x42;
    font_data['M'][4] = 0x42;
    font_data['M'][5] = 0x42;
    font_data['M'][6] = 0x42;
    font_data['M'][7] = 0x00;

    // N
    font_data['N'][0] = 0x42;
    font_data['N'][1] = 0x62;
    font_data['N'][2] = 0x52;
    font_data['N'][3] = 0x4A;
    font_data['N'][4] = 0x46;
    font_data['N'][5] = 0x42;
    font_data['N'][6] = 0x42;
    font_data['N'][7] = 0x00;

    // O
    font_data['O'][0] = 0x3C;
    font_data['O'][1] = 0x42;
    font_data['O'][2] = 0x42;
    font_data['O'][3] = 0x42;
    font_data['O'][4] = 0x42;
    font_data['O'][5] = 0x42;
    font_data['O'][6] = 0x3C;
    font_data['O'][7] = 0x00;

    // P
    font_data['P'][0] = 0x7C;
    font_data['P'][1] = 0x42;
    font_data['P'][2] = 0x42;
    font_data['P'][3] = 0x7C;
    font_data['P'][4] = 0x40;
    font_data['P'][5] = 0x40;
    font_data['P'][6] = 0x40;
    font_data['P'][7] = 0x00;

    // Q
    font_data['Q'][0] = 0x3C;
    font_data['Q'][1] = 0x42;
    font_data['Q'][2] = 0x42;
    font_data['Q'][3] = 0x42;
    font_data['Q'][4] = 0x42;
    font_data['Q'][5] = 0x46;
    font_data['Q'][6] = 0x3C;
    font_data['Q'][7] = 0x02; // petit pixel en bas Ã  droite pour distinguer le Q du O

    // R
    font_data['R'][0] = 0x7C;
    font_data['R'][1] = 0x42;
    font_data['R'][2] = 0x42;
    font_data['R'][3] = 0x7C;
    font_data['R'][4] = 0x48;
    font_data['R'][5] = 0x44;
    font_data['R'][6] = 0x42;
    font_data['R'][7] = 0x00;

    // S
    font_data['S'][0] = 0x3C;
    font_data['S'][1] = 0x42;
    font_data['S'][2] = 0x40;
    font_data['S'][3] = 0x3C;
    font_data['S'][4] = 0x02;
    font_data['S'][5] = 0x42;
    font_data['S'][6] = 0x3C;
    font_data['S'][7] = 0x00;

    // T
    font_data['T'][0] = 0x7E;
    font_data['T'][1] = 0x18;
    font_data['T'][2] = 0x18;
    font_data['T'][3] = 0x18;
    font_data['T'][4] = 0x18;
    font_data['T'][5] = 0x18;
    font_data['T'][6] = 0x18;
    font_data['T'][7] = 0x00;

    // U
    font_data['U'][0] = 0x42;
    font_data['U'][1] = 0x42;
    font_data['U'][2] = 0x42;
    font_data['U'][3] = 0x42;
    font_data['U'][4] = 0x42;
    font_data['U'][5] = 0x42;
    font_data['U'][6] = 0x3C;
    font_data['U'][7] = 0x00;

    // V
    font_data['V'][0] = 0x42;
    font_data['V'][1] = 0x42;
    font_data['V'][2] = 0x42;
    font_data['V'][3] = 0x42;
    font_data['V'][4] = 0x24;
    font_data['V'][5] = 0x24;
    font_data['V'][6] = 0x18;
    font_data['V'][7] = 0x00;

    // W
    font_data['W'][0] = 0x42;
    font_data['W'][1] = 0x42;
    font_data['W'][2] = 0x42;
    font_data['W'][3] = 0x42;
    font_data['W'][4] = 0x5A;
    font_data['W'][5] = 0x66;
    font_data['W'][6] = 0x42;
    font_data['W'][7] = 0x00;

    // X
    font_data['X'][0] = 0x42;
    font_data['X'][1] = 0x42;
    font_data['X'][2] = 0x24;
    font_data['X'][3] = 0x18;
    font_data['X'][4] = 0x24;
    font_data['X'][5] = 0x42;
    font_data['X'][6] = 0x42;
    font_data['X'][7] = 0x00;

    // Y
    font_data['Y'][0] = 0x42;
    font_data['Y'][1] = 0x42;
    font_data['Y'][2] = 0x24;
    font_data['Y'][3] = 0x18;
    font_data['Y'][4] = 0x18;
    font_data['Y'][5] = 0x18;
    font_data['Y'][6] = 0x18;
    font_data['Y'][7] = 0x00;

    // Z
    font_data['Z'][0] = 0x7E;
    font_data['Z'][1] = 0x02;
    font_data['Z'][2] = 0x04;
    font_data['Z'][3] = 0x08;
    font_data['Z'][4] = 0x10;
    font_data['Z'][5] = 0x20;
    font_data['Z'][6] = 0x7E;
    font_data['Z'][7] = 0x00;

}
static void dessiner_char(Uint8 *pixels, int img_width, int x, int y, char c) {
    if (c < 0 || c > 127) return;
    unsigned char *glyph = font_data[(int)c];

    // Vérifie si le caractère est défini
    int empty = 1;
    for (int i = 0; i < FONT_HEIGHT; i++) {
        if (glyph[i] != 0) {
            empty = 0;
            break;
        }
    }
    if (empty) {
        // Caractère non défini dans la font
        return;
    }

    int scaled_width = FONT_WIDTH * FONT_SCALE;
    int scaled_height = FONT_HEIGHT * FONT_SCALE;
    int char_x = x + (TAILLE_CASE - scaled_width) / 2;
    int char_y = y + (TAILLE_CASE - scaled_height) / 2;

    for (int row = 0; row < FONT_HEIGHT; row++) {
        for (int col = 0; col < FONT_WIDTH; col++) {
            int bit = (glyph[row] >> (7 - col)) & 1;
            if (bit) {
                // Dessiner un bloc FONT_SCALE x FONT_SCALE de pixels noirs
                for (int dy = 0; dy < FONT_SCALE; dy++) {
                    for (int dx = 0; dx < FONT_SCALE; dx++) {
                        int px = char_x + col * FONT_SCALE + dx;
                        int py = char_y + row * FONT_SCALE + dy;
                        Uint8 *p = pixels + py * img_width * 3 + px * 3;
                        p[0] = 0;   // R (noir)
                        p[1] = 0;   // G
                        p[2] = 0;   // B
                    }
                }
            }
        }
    }
}

// Lit la grille depuis le fichier
static Grille* lire_grille(const char *nom_fichier) {
    FILE *f = fopen(nom_fichier, "r");
    if (!f) {
        perror("Impossible d'ouvrir le fichier de la grille");
        return NULL;
    }

    Grille *grille = malloc(sizeof(Grille));
    grille->largeur = 0;
    grille->hauteur = 0;
    grille->cases = NULL;

    char ligne[1024];
    while (fgets(ligne, sizeof(ligne), f)) {
        ligne[strcspn(ligne, "\r\n")] = '\0';
        if (grille->largeur == 0) {
            grille->largeur = (int)strlen(ligne);
        } else {
            if ((int)strlen(ligne) != grille->largeur) {
                fprintf(stderr, "Lignes de longueurs différentes.\n");
                fclose(f);
                for (int i = 0; i < grille->hauteur; i++)
                    free(grille->cases[i]);
                free(grille->cases);
                free(grille);
                return NULL;
            }
        }

        grille->cases = realloc(grille->cases, (grille->hauteur + 1)*sizeof(char*));
        grille->cases[grille->hauteur] = malloc(grille->largeur + 1);
        strcpy(grille->cases[grille->hauteur], ligne);
        grille->hauteur++;
    }
    fclose(f);

    return grille;
}

static void liberer_grille(Grille *grille) {
    if (!grille) return;
    for (int i = 0; i < grille->hauteur; i++)
        free(grille->cases[i]);
    free(grille->cases);
    free(grille);
}

// Crée l'image sans grille, juste les lettres agrandies sur fond blanc
static void creer_image_grille(Grille *grille, const char *nom_image) {
    int largeur_image = grille->largeur * (TAILLE_CASE + MARGE) + MARGE;
    int hauteur_image = grille->hauteur * (TAILLE_CASE + MARGE) + MARGE;

    SDL_Surface *surface = SDL_CreateRGBSurfaceWithFormat(0, largeur_image, hauteur_image, 24, SDL_PIXELFORMAT_RGB24);
    if (!surface) {
        fprintf(stderr, "Erreur SDL_CreateRGBSurfaceWithFormat: %s\n", SDL_GetError());
        return;
    }

    Uint8 *pixels = (Uint8 *)surface->pixels;

    // Fond blanc
    for (int i = 0; i < hauteur_image; i++) {
        for (int j = 0; j < largeur_image; j++) {
            Uint8 *p = pixels + i * surface->pitch + j * 3;
            p[0] = 255; // R
            p[1] = 255; // G
            p[2] = 255; // B
        }
    }

    // Dessiner uniquement les lettres, sans contours, avec échelle
    for (int i = 0; i < grille->hauteur; i++) {
        for (int j = 0; j < grille->largeur; j++) {
            int x = MARGE + j * (TAILLE_CASE + MARGE);
            int y = MARGE + i * (TAILLE_CASE + MARGE);

            char c = grille->cases[i][j];
            if (c != '.' && c >= 'A' && c <= 'Z') {
                dessiner_char(pixels, largeur_image, x, y, c);
            }
        }
    }

    if (SDL_SaveBMP(surface, nom_image) != 0) {
        fprintf(stderr, "Erreur SDL_SaveBMP: %s\n", SDL_GetError());
    }

    SDL_FreeSurface(surface);
}

int main(int argc, char *argv[]) {
    const char *fichier_grille = FICHIER_GRILLE;
    const char *nom_image = NOM_IMAGE;

    if (argc >= 2) fichier_grille = argv[1];
    if (argc >= 3) nom_image = argv[2];

    init_font();

    Grille *grille = lire_grille(fichier_grille);
    if (!grille) {
        fprintf(stderr, "Erreur lors de la lecture de la grille.\n");
        return 1;
    }

    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        fprintf(stderr, "Erreur SDL_Init: %s\n", SDL_GetError());
        liberer_grille(grille);
        return 1;
    }

    creer_image_grille(grille, nom_image);
    liberer_grille(grille);

    SDL_Quit();

    printf("L'image de la grille sans lignes, avec des lettres agrandies, a été sauvegardée sous le nom '%s'.\n", nom_image);
    return 0;
}
