#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MARGIN 1

int is_red_pixel(Uint32 pixel, SDL_PixelFormat* format) {
    Uint8 r, g, b;
    SDL_GetRGB(pixel, format, &r, &g, &b);
    return (r > 200 && g < 50 && b < 50);
}

int is_black_or_white_pixel(Uint32 pixel, SDL_PixelFormat* format) {
    Uint8 r, g, b;
    SDL_GetRGB(pixel, format, &r, &g, &b);
    return (r == 255 && g == 255 && b == 255) || (r == 0 && g == 0 && b == 0);
}

void replace_red_pixel(Uint32* pixels, int x, int y, int width,
		int height, SDL_PixelFormat* format) {
    int directions[8][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1},
	    {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
    int white_count = 0;
    int black_count = 0;

    for (int i = 0; i < 8; i++) {
        int new_x = x + directions[i][0];
        int new_y = y + directions[i][1];
        if (new_x >= 0 && new_x < width && new_y >= 0 && new_y < height) {
            Uint8 r, g, b;
            SDL_GetRGB(pixels[new_y * width + new_x], format, &r, &g, &b);
            if (r == 255 && g == 255 && b == 255) {
                white_count++;
            } else if (r == 0 && g == 0 && b == 0) {
                black_count++;
            }
        }
    }

    Uint32 new_color;
    if (white_count == 0 && black_count == 0) {
        new_color = SDL_MapRGB(format, 0, 0, 0);
    } else {
        new_color = (white_count > black_count) ? SDL_MapRGB(format, 255, 255,
			255) : SDL_MapRGB(format, 0, 0, 0);
    }
    pixels[y * width + x] = new_color;
}

void replace_red_and_black_pixels_in_margin(Uint32* pixels, int x_min,
		int y_min, int x_max, int y_max, int width, int height,
		SDL_PixelFormat* format) {
    for (int y = y_min; y <= y_max; y++) {
        for (int x = x_min; x <= x_max; x++) {
            if (x < x_min + MARGIN || x > x_max - MARGIN || y < y_min + MARGIN
			    || y > y_max - MARGIN) {
                Uint8 r, g, b;
                SDL_GetRGB(pixels[y * width + x], format, &r, &g, &b);
                if (is_red_pixel(pixels[y * width + x], format)) {
                    pixels[y * width + x] = SDL_MapRGB(format, 255, 255, 255);
                }
            }
        }
    }
}

void ensure_non_empty_letter(Uint32* pixels, int x_min, int y_min, int x_max,
		int y_max, int width, int height, SDL_PixelFormat* format) {
    int black_pixel_found = 0;
    for (int y = y_min; y <= y_max && !black_pixel_found; y++) {
        for (int x = x_min; x <= x_max && !black_pixel_found; x++) {
            Uint8 r, g, b;
            SDL_GetRGB(pixels[y * width + x], format, &r, &g, &b);
            if (r == 0 && g == 0 && b == 0) {
                black_pixel_found = 1;
            }
        }
    }

    if (!black_pixel_found) {
        int middle_x = (x_min + x_max) / 2;
        for (int y = y_min + 4; y <= y_max - 4; y++) {
            pixels[y * width + middle_x] = SDL_MapRGB(format, 0, 0, 0);
        }
    }
}

void remove_isolated_black_pixels(Uint32* pixels, int width,
		int height, SDL_PixelFormat* format) {
    int directions[8][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1},
	    {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
    int* to_remove = calloc(width * height, sizeof(int));

    for (int y = 1; y < height - 1; y++) {
        for (int x = 1; x < width - 1; x++) {
            Uint8 r, g, b;
            SDL_GetRGB(pixels[y * width + x], format, &r, &g, &b);
            if (r == 0 && g == 0 && b == 0) {
                int white_count = 0;
                for (int i = 0; i < 8; i++) {
                    int new_x = x + directions[i][0];
                    int new_y = y + directions[i][1];
                    Uint8 nr, ng, nb;
                    SDL_GetRGB(pixels[new_y * width + new_x], format,
				    &nr, &ng, &nb);
                    if (nr == 255 && ng == 255 && nb == 255) {
                        white_count++;
                    }
                }
                if (white_count == 8) {
                    to_remove[y * width + x] = 1;
                }
            }
        }
    }

    for (int y = 1; y < height - 1; y++) {
        for (int x = 1; x < width - 1; x++) {
            if (to_remove[y * width + x]) {
                pixels[y * width + x] = SDL_MapRGB(format, 255, 255, 255);
            }
        }
    }

    free(to_remove);
}

void save_letter_image(const char* filename, SDL_Surface* surface,
		SDL_Rect* rect) {
    SDL_Surface* letter_surface = SDL_CreateRGBSurfaceWithFormat(0, rect->w,
		    rect->h, surface->format->BitsPerPixel,
		    surface->format->format);
    if (!letter_surface) {
        printf("Surface error: %s\n", SDL_GetError());
        return;
    }

    if (SDL_BlitSurface(surface, rect, letter_surface, NULL) < 0) {
        printf("Error while copying: %s\n", SDL_GetError());
        SDL_FreeSurface(letter_surface);
        return;
    }

    if (IMG_SavePNG(letter_surface, filename) != 0) {
        printf("Could not save image: %s\n", IMG_GetError());
    } else {
        printf("Image saved as: %s\n", filename);
    }

    SDL_FreeSurface(letter_surface);
}

void explore_region(int start_x, int start_y, int width, int height,
		Uint32* pixels, int** visited, int* x_min, int* y_min,
		int* x_max, int* y_max, SDL_PixelFormat* format) {
    int queue_size = width * height;
    int queue[queue_size][2];
    int front = 0;
    int back = 0;

    queue[back][0] = start_x;
    queue[back][1] = start_y;
    back++;
    visited[start_y][start_x] = 1;

    while (front < back) {
        int x = queue[front][0];
        int y = queue[front][1];
        front++;

        if (x < *x_min) *x_min = x;
        if (x > *x_max) *x_max = x;
        if (y < *y_min) *y_min = y;
        if (y > *y_max) *y_max = y;

        replace_red_pixel(pixels, x, y, width, height, format);

        int directions[8][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1},
		{1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
        for (int i = 0; i < 8; i++) {
            int new_x = x + directions[i][0];
            int new_y = y + directions[i][1];

            if (new_x >= 0 && new_x < width && new_y >= 0 && new_y < height) {
                if (!visited[new_y][new_x]
				&& is_red_pixel(pixels[new_y * width + new_x],
					format)) {
                    visited[new_y][new_x] = 1;
                    queue[back][0] = new_x;
                    queue[back][1] = new_y;
                    back++;
                }
            }
        }
    }
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Usage: %s <image_file>\n", argv[0]);
        return 1;
    }

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("Error SDL_Init: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Surface* img = IMG_Load(argv[1]);
    if (img == NULL) {
        printf("Error IMG_Load: %s\n", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Surface* converted_img = SDL_ConvertSurfaceFormat(img,
		    SDL_PIXELFORMAT_RGBA32, 0);
    SDL_FreeSurface(img);
    img = converted_img;
    if (img == NULL) {
        printf("Error SDL_ConvertSurfaceFormat: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    Uint32* pixels = (Uint32*)img->pixels;
    int width = img->w;
    int height = img->h;
    SDL_PixelFormat* format = img->format;

    int** visited = malloc(height * sizeof(int*));
    for (int i = 0; i < height; i++) {
        visited[i] = calloc(width, sizeof(int));
    }

    int letter_count = 0;
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            if (is_red_pixel(pixels[y * width + x], format) && !visited[y][x]) {
                //printf("Red pixel detected(%d, %d)\n", x, y);

                int x_min = x;
                int y_min = y;
                int x_max = x;
                int y_max = y;

                explore_region(x, y, width, height, pixels, visited,
				&x_min, &y_min, &x_max, &y_max, format);

                int new_x_min = (x_min - MARGIN < 0) ? 0 : x_min - MARGIN;
                int new_y_min = (y_min - MARGIN < 0) ? 0 : y_min - MARGIN;
                int new_x_max = (x_max + MARGIN >= width) ? width - 1
			: x_max + MARGIN;
                int new_y_max = (y_max + MARGIN >= height) ? height - 1
			: y_max + MARGIN;

                replace_red_and_black_pixels_in_margin(pixels, new_x_min,
				new_y_min, new_x_max, new_y_max, width, height,
				format);
                ensure_non_empty_letter(pixels, new_x_min, new_y_min,
				new_x_max, new_y_max, width, height, format);

                SDL_Rect letter_rect = { new_x_min, new_y_min,
			new_x_max - new_x_min + 1, new_y_max - new_y_min + 1 };
                if (letter_rect.w <= 0 || letter_rect.h <= 0) {
                    printf("Invalid region\n");
                    continue;
                }

                printf("Letter extract: x_min=%d,y_min=%d, x_max=%d,y_max=%d\n"
				, new_x_min, new_y_min, new_x_max, new_y_max);

                char filename[64];
                snprintf(filename, sizeof(filename), "letter_%d.png",
				letter_count++);
                save_letter_image(filename, img, &letter_rect);
            }
        }
    }

    remove_isolated_black_pixels(pixels, width, height, format);

    for (int i = 0; i < height; i++) {
        free(visited[i]);
    }
    free(visited);

    SDL_FreeSurface(img);
    SDL_Quit();

    return 0;
}

