#include <stdio.h>
#include <math.h>

#define MAX_GRID_SIZE 100

typedef struct
{
    int x;
    int y;
} Position;

char grid[MAX_GRID_SIZE][MAX_GRID_SIZE];
int rows = 0;
int cols = 0;


void to_uppercase(char *str)
{
    for (; *str; ++str) {
        if (*str >= 'a' && *str <= 'z') {
            *str -= 32;
        }
    }
}


int load_grid(const char *filename)
{
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        printf("Error opening grid file\n");
        return -1;
    }

    char line[MAX_GRID_SIZE];
    while (fgets(line, sizeof(line), fp))
    {
        size_t len = 0;
        while (line[len] != '\n' && line[len] != '\0'
			&& len < MAX_GRID_SIZE) {
            len++;
        }
        line[len] = '\0';

        if (len > cols)
            cols = len;

        to_uppercase(line);

        for (int i = 0; i < len; i++)
        {
            grid[rows][i] = line[i];
        }
        grid[rows][len] = '\0';
        rows++;
    }
    fclose(fp);
    return 0;
}

int search_direction(int x, int y, int dx, int dy,
		const char *word, Position *start, Position *end) {
    int len = 0;
    while (word[len] != '\0') len++;
    for (int i = 0; i < len; i++)
    {   
        int nx = x + i * dx;
        int ny = y + i * dy;

        if (nx < 0 || ny < 0 || ny >= rows || nx >= MAX_GRID_SIZE
			|| grid[ny][nx] == '\0')
            return 0;

        if (grid[ny][nx] != word[i])
            return 0;
    }
    start->x = x;
    start->y = y;
    end->x = x + (len - 1) * dx;
    end->y = y + (len - 1) * dy;
    return 1;
}

int main(int argc, char *argv[])
{
    if (argc != 3) {
        printf("Usage: ./solver grid_file word\n");
        return 1;
    }

    const char *grid_file = argv[1];
    char word[MAX_GRID_SIZE];
    int word_len = 0;
    while (argv[2][word_len] != '\0' && word_len < MAX_GRID_SIZE - 1) {
        word[word_len] = argv[2][word_len];
        word_len++;
    }
    word[word_len] = '\0';

    to_uppercase(word);

    if (load_grid(grid_file) != 0) {
        return 1;
    }

    Position start, end;
    int found = 0;

    int directions[8][2] = {
        {1, 0},
        {0, 1},
        {-1, 0},
        {0, -1},
        {1, 1},
        {-1, -1},
        {1, -1},
        {-1, 1}
    };

    for (int y = 0; y < rows; y++) {
        int row_len = 0;
        while (grid[y][row_len] != '\0') row_len++;
        for (int x = 0; x < row_len; x++) {
            for (int d = 0; d < 8; d++) {
                if (search_direction(x, y,
					directions[d][0],
					directions[d][1], word,
					&start, &end)) {
                    printf("(%d,%d)(%d,%d)\n", start.x, start.y,
				    end.x, end.y);
                    found = 1;
                    return 0;
                }
            }
        }
    }

    if (!found) {
        printf("Not Found\n");
    }

    return 0;
}
