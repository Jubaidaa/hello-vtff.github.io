#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>

void split_image(SDL_Surface* surface, const char* file_left, const char* file_right) {
    if (!surface) {
        fprintf(stderr, "Invalid surface.\n");
        return;
    }

    // Define magenta color
    Uint32 magenta = SDL_MapRGB(surface->format, 255, 0, 255);

    int width = surface->w;
    int height = surface->h;

    int split_x = -1;
    for (int x = 0; x < width; x++) {
        int is_magenta = 1;
        for (int y = 0; y < height; y++) {
            Uint32* pixels = (Uint32*)surface->pixels;
            Uint32 pixel_color = pixels[y * width + x];

            // Extract RGB values of the current pixel
            Uint8 r, g, b;
            SDL_GetRGB(pixel_color, surface->format, &r, &g, &b);

            if (pixel_color != magenta) {
                is_magenta = 0;
                break;
            }
        }
        if (is_magenta) {
            split_x = x;
            break;
        }
    }

    if (split_x == -1) {
        fprintf(stderr, "No separating line found.\n");
        return;
    }

    // Create the surfaces
    SDL_Surface* left_surface = SDL_CreateRGBSurface(0, split_x, height, surface->format->BitsPerPixel,
        surface->format->Rmask, surface->format->Gmask,
        surface->format->Bmask, surface->format->Amask);
    SDL_Surface* right_surface = SDL_CreateRGBSurface(0, width - split_x - 1, height, surface->format->BitsPerPixel,
        surface->format->Rmask, surface->format->Gmask,
        surface->format->Bmask, surface->format->Amask);

    if (!left_surface || !right_surface) {
        fprintf(stderr, "Error creating surfaces.\n");
        if (left_surface) SDL_FreeSurface(left_surface);
        if (right_surface) SDL_FreeSurface(right_surface);
        return;
    }

    // Copy pixels to the left surface
    for (int y = 0; y < height; y++) {
        Uint32* src_pixels = (Uint32*)surface->pixels;
        Uint32* dst_pixels = (Uint32*)left_surface->pixels;
        memcpy(&dst_pixels[y * left_surface->w], &src_pixels[y * width], split_x * sizeof(Uint32));
    }

    // Copy pixels to the right surface
    for (int y = 0; y < height; y++) {
        Uint32* src_pixels = (Uint32*)surface->pixels;
        Uint32* dst_pixels = (Uint32*)right_surface->pixels;
        memcpy(&dst_pixels[y * right_surface->w], &src_pixels[y * width + split_x + 1], (width - split_x - 1) * sizeof(Uint32));
    }

    // Save the parts
    if (IMG_SavePNG(left_surface, file_left) != 0) {
        fprintf(stderr, "Error saving the left part: %s\n", IMG_GetError());
    } else {
        printf("Left part saved to %s\n", file_left);
    }

    if (IMG_SavePNG(right_surface, file_right) != 0) {
        fprintf(stderr, "Error saving the right part: %s\n", IMG_GetError());
    } else {
        printf("Right part saved to %s\n", file_right);
    }

    // Free the surfaces
    SDL_FreeSurface(left_surface);
    SDL_FreeSurface(right_surface);
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <input_image>\n", argv[0]);
        return 1;
    }

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "Error initializing SDL: %s\n", SDL_GetError());
        return 1;
    }

    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        fprintf(stderr, "Error initializing SDL_image: %s\n", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Surface* image = IMG_Load(argv[1]);
    if (!image) {
        fprintf(stderr, "Error loading image: %s\n", IMG_GetError());
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // Call split_image with the generated output file names
    split_image(image, "left_part.png", "right_part.png");

    SDL_FreeSurface(image);
    IMG_Quit();
    SDL_Quit();

    return 0;
}

