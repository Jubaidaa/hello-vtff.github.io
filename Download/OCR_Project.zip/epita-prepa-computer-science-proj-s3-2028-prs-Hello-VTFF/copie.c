#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>

#define MAGENTA_COLOR SDL_MapRGB(surface->format, 255, 0, 255) // Couleur magenta

// Fonction pour enregistrer l'image
void save_image(const char* filename, SDL_Surface* surface) {
    if (IMG_SavePNG(surface, filename) != 0) {
        printf("IMG_SavePNG Error: %s\n", IMG_GetError());
    } else {
        printf("Image saved as %s\n", filename);
    }
}

// Fonction pour trouver la ligne magenta sur l'image
int find_magenta_line(SDL_Surface* surface) {
    int width = surface->w;
    int height = surface->h;

    // Parcourir chaque colonne pour trouver la ligne magenta
    for (int x = 0; x < width; x++) {
        int is_magenta = 1;
        for (int y = 0; y < height; y++) {
            Uint32* pixels = (Uint32*)surface->pixels;
            Uint32 pixel_color = pixels[y * width + x];

            // Vérifier si le pixel est magenta
            if (pixel_color != MAGENTA_COLOR) {
                is_magenta = 0;
                break;
            }
        }
        if (is_magenta) {
            return x; // Retourne l'index de la colonne magenta
        }
    }
    return -1; // Si la ligne magenta n'est pas trouvée
}

// Fonction pour tracer une ligne magenta sur une autre image
void draw_magenta_line(SDL_Surface* surface, int magenta_x, SDL_Surface* target_surface) {
    if (magenta_x == -1) {
        printf("No magenta line found.\n");
        return;
    }

    int width = target_surface->w;
    int height = target_surface->h;

    // Tracer la ligne magenta sur l'image cible à la même position x, y
    for (int y = 0; y < height; y++) {
        Uint32* pixels = (Uint32*)target_surface->pixels;
        pixels[y * width + magenta_x] = MAGENTA_COLOR; // Tracer sur la position (magenta_x, y)
    }
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <source_image> <target_image>\n", argv[0]);
        return 1;
    }

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "SDL_Init Error: %s\n", SDL_GetError());
        return 1;
    }

    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        fprintf(stderr, "IMG_Init Error: %s\n", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    // Charger l'image source (qui contient la ligne magenta)
    SDL_Surface* source_image = IMG_Load(argv[1]);
    if (!source_image) {
        fprintf(stderr, "IMG_Load Error: %s\n", IMG_GetError());
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // Charger l'image cible (sur laquelle la ligne magenta sera tracée)
    SDL_Surface* target_image = IMG_Load(argv[2]);
    if (!target_image) {
        fprintf(stderr, "IMG_Load Error: %s\n", IMG_GetError());
        SDL_FreeSurface(source_image);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    // Trouver la ligne magenta sur l'image source
    int magenta_x = find_magenta_line(source_image);
    
    // Tracer la ligne magenta sur l'image cible
    draw_magenta_line(source_image, magenta_x, target_image);

    // Sauvegarder l'image modifiée
    save_image("output_image.png", target_image);

    // Libérer les surfaces et quitter SDL
    SDL_FreeSurface(source_image);
    SDL_FreeSurface(target_image);
    IMG_Quit();
    SDL_Quit();

    return 0;
}

