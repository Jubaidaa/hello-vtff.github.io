#include <stdio.h>
#include <stdlib.h>
#include <png.h>
#include <string.h>

#define BINARIZE_THRESHOLD 128
#define LARGE_COMPONENT_SIZE 200

int dx[4] = {1, -1, 0, 0};
int dy[4] = {0, 0, 1, -1};

static void binarize_image(png_byte **row_pointers, int width, int height) {
    for (int y = 0; y < height; y++) {
        png_byte *row = row_pointers[y];
        for (int x = 0; x < width; x++) {
            png_byte r = row[x*4];
            png_byte g = row[x*4+1];
            png_byte b = row[x*4+2];
            int brightness = (r + g + b) / 3;
            if (brightness < BINARIZE_THRESHOLD) {
                // Black pixel
                row[x*4]   = 0;
                row[x*4+1] = 0;
                row[x*4+2] = 0;
                row[x*4+3] = 255;
            } else {
                // White pixel
                row[x*4]   = 255;
                row[x*4+1] = 255;
                row[x*4+2] = 255;
                row[x*4+3] = 255;
            }
        }
    }
}

static int flood_fill_remove_black(png_byte **row_pointers, int width, int height, int start_x, int start_y) {
    typedef struct { int x, y; } Point;
    Point *queue = malloc(width * height * sizeof(Point));
    int front = 0, back = 0;
    queue[back++] = (Point){start_x, start_y};

    // Turn the starting pixel white
    row_pointers[start_y][start_x*4]   = 255;
    row_pointers[start_y][start_x*4+1] = 255;
    row_pointers[start_y][start_x*4+2] = 255;
    row_pointers[start_y][start_x*4+3] = 255;

    int removed_count = 1; // Starting pixel removed

    while (front < back) {
        Point p = queue[front++];
        for (int i = 0; i < 4; i++) {
            int nx = p.x + dx[i];
            int ny = p.y + dy[i];
            if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;

            png_byte *row = row_pointers[ny];
            int brightness = row[nx*4]; // After binarization: 0=black, 255=white
            if (brightness == 0) {
                // Black pixel found, remove it
                row[nx*4]   = 255;
                row[nx*4+1] = 255;
                row[nx*4+2] = 255;
                row[nx*4+3] = 255;
                queue[back++] = (Point){nx, ny};
                removed_count++;
            }
        }
    }

    free(queue);
    return removed_count;
}

static void read_png_file(const char *filename,
                          png_structp *png_ptr,
                          png_infop *info_ptr,
                          png_byte ***row_pointers,
                          int *width, int *height, int *color_type, int *bit_depth)
{
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        fprintf(stderr, "Error: Cannot open file %s for reading.\n", filename);
        exit(1);
    }

    unsigned char header[8];
    fread(header, 1, 8, fp);
    if(png_sig_cmp(header, 0, 8)) {
        fprintf(stderr, "Error: File %s is not a valid PNG.\n", filename);
        fclose(fp);
        exit(1);
    }

    *png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if(!*png_ptr) {
        fprintf(stderr, "png_create_read_struct failed.\n");
        fclose(fp);
        exit(1);
    }

    *info_ptr = png_create_info_struct(*png_ptr);
    if(!*info_ptr) {
        fprintf(stderr, "png_create_info_struct failed.\n");
        png_destroy_read_struct(png_ptr, NULL, NULL);
        fclose(fp);
        exit(1);
    }

    if (setjmp(png_jmpbuf(*png_ptr))) {
        fprintf(stderr, "Error during png_init_io.\n");
        png_destroy_read_struct(png_ptr, info_ptr, NULL);
        fclose(fp);
        exit(1);
    }

    png_init_io(*png_ptr, fp);
    png_set_sig_bytes(*png_ptr, 8);

    png_read_info(*png_ptr, *info_ptr);

    *width = png_get_image_width(*png_ptr, *info_ptr);
    *height = png_get_image_height(*png_ptr, *info_ptr);
    *color_type = png_get_color_type(*png_ptr, *info_ptr);
    *bit_depth = png_get_bit_depth(*png_ptr, *info_ptr);

    if (*color_type == PNG_COLOR_TYPE_PALETTE)
        png_set_palette_to_rgb(*png_ptr);

    if (*color_type == PNG_COLOR_TYPE_GRAY && *bit_depth < 8)
        png_set_expand_gray_1_2_4_to_8(*png_ptr);

    if (png_get_valid(*png_ptr, *info_ptr, PNG_INFO_tRNS))
        png_set_tRNS_to_alpha(*png_ptr);

    if (*bit_depth == 16)
        png_set_strip_16(*png_ptr);

    if (*color_type == PNG_COLOR_TYPE_GRAY ||
        *color_type == PNG_COLOR_TYPE_GRAY_ALPHA)
        png_set_gray_to_rgb(*png_ptr);

    if (*color_type == PNG_COLOR_TYPE_RGB)
        png_set_add_alpha(*png_ptr, 0xff, PNG_FILLER_AFTER);

    png_read_update_info(*png_ptr, *info_ptr);

    *row_pointers = (png_byte**) malloc(sizeof(png_byte*) * (*height));
    for (int y=0; y<*height; y++) {
        (*row_pointers)[y] = (png_byte*) malloc(png_get_rowbytes(*png_ptr, *info_ptr));
    }

    png_read_image(*png_ptr, *row_pointers);

    fclose(fp);
}

static void write_png_file(const char *filename, png_structp png_ptr, png_infop info_ptr, png_byte **row_pointers, int width, int height)
{
    FILE *fp = fopen(filename, "wb");
    if(!fp) {
        fprintf(stderr, "Error: Cannot open file %s for writing.\n", filename);
        exit(1);
    }

    png_structp write_png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (!write_png_ptr) {
        fprintf(stderr, "png_create_write_struct failed.\n");
        fclose(fp);
        exit(1);
    }

    png_infop write_info_ptr = png_create_info_struct(write_png_ptr);
    if (!write_info_ptr) {
        fprintf(stderr, "png_create_info_struct failed.\n");
        png_destroy_write_struct(&write_png_ptr, (png_infopp)NULL);
        fclose(fp);
        exit(1);
    }

    if (setjmp(png_jmpbuf(write_png_ptr))) {
        fprintf(stderr, "Error during png_init_io.\n");
        png_destroy_write_struct(&write_png_ptr, &write_info_ptr);
        fclose(fp);
        exit(1);
    }

    png_init_io(write_png_ptr, fp);

    png_set_IHDR(write_png_ptr, write_info_ptr, width, height,
                 8, PNG_COLOR_TYPE_RGBA, PNG_INTERLACE_NONE,
                 PNG_COMPRESSION_TYPE_BASE, PNG_FILTER_TYPE_BASE);

    png_write_info(write_png_ptr, write_info_ptr);
    png_write_image(write_png_ptr, row_pointers);
    png_write_end(write_png_ptr, write_info_ptr);

    png_destroy_write_struct(&write_png_ptr, &write_info_ptr);
    fclose(fp);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s input.png\n", argv[0]);
        return 1;
    }

    png_structp png_ptr;
    png_infop info_ptr;
    png_byte **row_pointers;
    int width, height, color_type, bit_depth;

    read_png_file(argv[1], &png_ptr, &info_ptr, &row_pointers, &width, &height, &color_type, &bit_depth);

    // Binarize the image
    binarize_image(row_pointers, width, height);

    int large_component_found = 0;
    int cumulative_removed = 0; // Track removals

    // Scan the entire image for black pixels.
    // If found, remove it. 
    // If <200 pixels removed, reset cumulative_removed = 0 and continue.
    // If ≥200 pixels removed, set cumulative_removed and stop.
    for (int y = 0; y < height && !large_component_found; y++) {
        png_byte *row = row_pointers[y];
        for (int x = 0; x < width && !large_component_found; x++) {
            int brightness = row[x*4]; // 0 or 255
            if (brightness == 0) { // Black pixel found
                int removed = flood_fill_remove_black(row_pointers, width, height, x, y);
                if (removed >= LARGE_COMPONENT_SIZE) {
                    cumulative_removed = removed;
                    large_component_found = 1;
                } else {
                    // Less than 200 pixels, reset counter
                    cumulative_removed = 0;
                }
            }
        }
    }

    write_png_file("cleaned.png", png_ptr, info_ptr, row_pointers, width, height);

    // Cleanup
    for (int y=0; y<height; y++) {
        free(row_pointers[y]);
    }
    free(row_pointers);
    png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

    if (large_component_found) {
        printf("Removed a large component (%d pixels) and stopped.\n", cumulative_removed);
    } else {
        printf("No large component (≥200 pixels) found. Result saved to cleaned.png.\n");
    }

    return 0;
}

