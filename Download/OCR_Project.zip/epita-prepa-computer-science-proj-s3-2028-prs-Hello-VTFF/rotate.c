#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <math.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        return EXIT_FAILURE;
    }

    const char *image_path = argv[1];
    const char *output_path = "rotated_result.png";
    long angle = strtoul(argv[2], NULL, 10);

    if (SDL_Init(SDL_INIT_VIDEO) != 0)
    {
        SDL_Log("Error SDL_Init: %s", SDL_GetError());
        return 1;
    }

    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG))
    {
        SDL_Log("Error SDL_image: %s", IMG_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Surface *image_surface = IMG_Load(image_path);
    if (!image_surface)
    {
        SDL_Log("Error img %s: %s", image_path, IMG_GetError());
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    SDL_Window *window = SDL_CreateWindow("Window is open",
                    SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                    image_surface->w, image_surface->h, SDL_WINDOW_HIDDEN);
    if (!window)
    {
        SDL_Log("Failed to load window: %s", SDL_GetError());
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1,
                    SDL_RENDERER_SOFTWARE);
    if (!renderer)
    {
        SDL_Log("Failed to load renderer: %s", SDL_GetError());
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer,
                    image_surface);
    if (!texture)
    {
        SDL_Log("Failed texture: %s", SDL_GetError());
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    int w = image_surface->w;
    int h = image_surface->h;
    double rad_angle = angle * (M_PI / 180.0);

    int new_w = (int)(fabs(w * cos(rad_angle)) + fabs(h * sin(rad_angle)));
    int new_h = (int)(fabs(w * sin(rad_angle)) + fabs(h * cos(rad_angle)));

    SDL_Texture *target_texture = SDL_CreateTexture(renderer,
                    SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET,
                    new_w, new_h);
    if (!target_texture)
    {
        SDL_Log("Failed target texture: %s", SDL_GetError());
        SDL_DestroyTexture(texture);
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    if (SDL_SetRenderTarget(renderer, target_texture) != 0)
    {
        SDL_Log("Failed target renderer: %s", SDL_GetError());
    }

    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_RenderClear(renderer);

    SDL_Point center = { w / 2, h / 2 };
    SDL_Rect dest_rect = { (new_w - w) / 2, (new_h - h) / 2, w, h };

    if (SDL_RenderCopyEx(renderer, texture, NULL, &dest_rect,
                            (double)angle, &center, SDL_FLIP_NONE) != 0)
    {
        SDL_Log("Failed to copy: %s", SDL_GetError());
    }
    SDL_SetRenderTarget(renderer, NULL);
    SDL_Surface *rotated_surface = SDL_CreateRGBSurfaceWithFormat(0, new_w,
                    new_h, 32, SDL_PIXELFORMAT_RGBA32);
    if (!rotated_surface)
    {
        SDL_Log("Error surface: %s", SDL_GetError());
        SDL_DestroyTexture(target_texture);
        SDL_DestroyTexture(texture);
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    if (SDL_SetRenderTarget(renderer, target_texture) != 0)
    {
        SDL_Log("Error next target: %s", SDL_GetError());
    }
    if (SDL_RenderReadPixels(renderer, NULL, SDL_PIXELFORMAT_RGBA32,
                            rotated_surface->pixels,
                            rotated_surface->pitch) != 0)
    {
        SDL_Log("Fail pixels: %s", SDL_GetError());
        SDL_FreeSurface(rotated_surface);
        SDL_DestroyTexture(target_texture);
        SDL_DestroyTexture(texture);
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_FreeSurface(image_surface);
        IMG_Quit();
        SDL_Quit();
        return 1;
    }

    if (IMG_SavePNG(rotated_surface, output_path) != 0)
    {
        SDL_Log("Could not save image: %s", IMG_GetError());
    } else
    {
        SDL_Log("Image saved as: %s", output_path);
    }

    SDL_FreeSurface(rotated_surface);
    SDL_DestroyTexture(target_texture);
    SDL_DestroyTexture(texture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_FreeSurface(image_surface);
    IMG_Quit();
    SDL_Quit();

    return 0;
}

