#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define TAILLE_GRILLE 27

char grille[TAILLE_GRILLE][TAILLE_GRILLE];

// Prototypes des fonctions
void initialiser_grille();
int placer_mot(char *mot);
void remplir_cases_vides();
void ecrire_grille_dans_fichier();
void to_upper(char *mot);

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s <nombre_de_mots> <mot1> <mot2> ...\n", argv[0]);
        return 1;
    }

    int nombre_mots = atoi(argv[1]);

    if (argc != nombre_mots + 2) {
        printf("Erreur: Le nombre de mots ne correspond pas aux mots fournis.\n");
        return 1;
    }

    // Vérification que les mots peuvent entrer dans la grille
    for (int i = 0; i < nombre_mots; i++) {
        if (strlen(argv[i + 2]) > TAILLE_GRILLE) {
            printf("Erreur: Le mot '%s' est trop long pour la taille de la grille.\n", argv[i + 2]);
            return 1;
        }
    }

    // Initialisation de la grille
    initialiser_grille();

    // Initialisation du générateur de nombres aléatoires
    srand(time(NULL));

    // Traitement et placement des mots
    for (int i = 0; i < nombre_mots; i++) {
        to_upper(argv[i + 2]);
        if (!placer_mot(argv[i + 2])) {
            printf("Impossible de placer le mot: %s\n", argv[i + 2]);
        }
    }

    // Remplissage des cases vides avec des lettres aléatoires
    remplir_cases_vides();

    // Écriture de la grille dans le fichier
    ecrire_grille_dans_fichier();

    return 0;
}

void to_upper(char *mot) {
    for (int i = 0; mot[i]; i++) {
        // Vérifie si le caractère est une lettre minuscule
        if (mot[i] >= 'a' && mot[i] <= 'z') {
            mot[i] = mot[i] - 'a' + 'A';
        }
        // Vérifie si le caractère n'est pas une lettre majuscule
        else if (!(mot[i] >= 'A' && mot[i] <= 'Z')) {
            printf("Erreur: Le mot '%s' contient des caractères invalides.\n", mot);
            exit(1);
        }
    }
}

void initialiser_grille() {
    for (int i = 0; i < TAILLE_GRILLE; i++) {
        for (int j = 0; j < TAILLE_GRILLE; j++) {
            grille[i][j] = '.';
        }
    }
}

int placer_mot(char *mot) {
    int longueur = strlen(mot);
    int direction;
    int delta_ligne, delta_colonne;
    int ligne, colonne;
    int essais = 1000; // Augmentation du nombre d'essais pour les longs mots

    while (essais--) {
        ligne = rand() % TAILLE_GRILLE;
        colonne = rand() % TAILLE_GRILLE;

        direction = rand() % 8; // 8 directions possibles

        switch (direction) {
            case 0: delta_ligne = 0; delta_colonne = 1; break;  // Droite
            case 1: delta_ligne = 1; delta_colonne = 0; break;  // Bas
            case 2: delta_ligne = 0; delta_colonne = -1; break; // Gauche
            case 3: delta_ligne = -1; delta_colonne = 0; break; // Haut
            case 4: delta_ligne = 1; delta_colonne = 1; break;  // Diagonale bas-droite
            case 5: delta_ligne = -1; delta_colonne = -1; break;// Diagonale haut-gauche
            case 6: delta_ligne = -1; delta_colonne = 1; break; // Diagonale haut-droite
            case 7: delta_ligne = 1; delta_colonne = -1; break; // Diagonale bas-gauche
            default: delta_ligne = 0; delta_colonne = 0; break;
        }

        int fin_ligne = ligne + delta_ligne * (longueur - 1);
        int fin_colonne = colonne + delta_colonne * (longueur - 1);

        // Vérifier si le mot dépasse les limites de la grille
        if (fin_ligne < 0 || fin_ligne >= TAILLE_GRILLE || fin_colonne < 0 || fin_colonne >= TAILLE_GRILLE) {
            continue;
        }

        // Vérifier si le mot peut être placé (cases vides ou lettres correspondantes)
        int peut_placer = 1;
        for (int i = 0; i < longueur; i++) {
            char lettre_actuelle = grille[ligne + i * delta_ligne][colonne + i * delta_colonne];
            if (lettre_actuelle != '.' && lettre_actuelle != mot[i]) {
                peut_placer = 0;
                break;
            }
        }

        if (peut_placer) {
            // Placer le mot dans la grille
            for (int i = 0; i < longueur; i++) {
                grille[ligne + i * delta_ligne][colonne + i * delta_colonne] = mot[i];
            }
            return 1;
        }
    }
    // Échec du placement du mot
    return 0;
}

void remplir_cases_vides() {
    for (int i = 0; i < TAILLE_GRILLE; i++) {
        for (int j = 0; j < TAILLE_GRILLE; j++) {
            if (grille[i][j] == '.') {
                grille[i][j] = 'A' + rand() % 26;
            }
        }
    }
}

void ecrire_grille_dans_fichier() {
    FILE *fichier = fopen("grid_output.txt", "w");
    if (fichier == NULL) {
        printf("Erreur lors de l'ouverture du fichier pour écriture.\n");
        return;
    }

    for (int i = 0; i < TAILLE_GRILLE; i++) {
        for (int j = 0; j < TAILLE_GRILLE; j++) {
            fprintf(fichier, "%c", grille[i][j]);
        }
        fprintf(fichier, "\n");
    }

    fclose(fichier);
}
