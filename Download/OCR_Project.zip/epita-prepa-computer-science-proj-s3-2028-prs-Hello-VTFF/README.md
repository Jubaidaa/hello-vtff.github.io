# Bienvenue dans la version 1.0.1 de notre projet

Chaque programme s'utilise sous la forme :

1. **Nom du programme**
2. **Instruction d'exécution**
3. **Exemple**

Après avoir effectué un : $make . Il suffit de copier les commandes afin d'exécuter les programmes.

## Liste des programmes disponibles :

---

### `rotate.c`

*Veuillez vous assurer que l'image est au format `.png`.*

**Instruction d'exécution :**

```bash
./rotate <image.png> <angle>
```

**Exemple :**

```bash
./rotate 90.png 90
```

---

### `solver.c`

**Instruction d'exécution :**

```bash
./solver <fichier.txt> <mot>
```

**Exemple :**

```bash
./solver grid.txt hello
```

---

### `clean.c`

**Instruction d'exécution :**

```bash
./clean <img.png> 
```

**Exemple :**

```bash
./clean Image_niveau2_1.png
```

---

### `masquage.c`

**Instruction d'exécution :**

```bash
./masquage <img.png> <Treshold>
```

**Exemple :**

```bash
./solver image.png 200
```

---

### `XNOR.c`

**Instruction d'exécution :**

```bash
./XNOR
```

**Exemple :**

```bash
./XNOR
```

---

### `Separer_image.c`

**Instruction d'exécution :**

```bash
./Separer_image <Processed_image.png>
```

**Exemple :**

```bash
./Separer_image Image_niveau2_1.png
```

---

### `Separer_haut.c`

**Instruction d'exécution :**

```bash
./Separer_haut <Processed_image.png>
```

**Exemple :**

```bash
./Separer_haut Image_niveau2_1.png
```

---
### `Separer_sans_draw.c`

**Instruction d'exécution :**

```bash
./Separer_sans_draw <Processed_image.png>
```

**Exemple :**

```bash
./Separer_sans_draw Image_niveau2_1.png
```

---
### `extraction.c`

**Instruction d'exécution :**

```bash
./extraction <Separer_image_output.png>
```

**Exemple :**

```bash
./extraction output.png
```

---
### `testEnca.c`

**Instruction d'exécution :**

```bash
./testEnca <Separer_image_output.png> <start_x> <start_y> <width> <height>
```

**Exemple :**

```bash
./testEnca output.png 0 0 228 594
```

---
